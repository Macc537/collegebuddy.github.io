package com.example.collegebuddy.utils;

import android.content.Context;
import android.content.SharedPreferences;

import com.example.collegebuddy.R;
import com.example.collegebuddy.constants.ApplicationConstants;

public class SharedPrefUtils {

    private Context context;
    SharedPreferences sharedPref;

    public SharedPrefUtils(Context context){
        this.context = context;
        this.sharedPref = context.getSharedPreferences(ApplicationConstants.SHAREDPREF_FILE,
                context.MODE_PRIVATE);
    }

    public void getAuthData(){
    }

    public void clearAuthSavedData(){
        SharedPreferences.Editor editor = sharedPref.edit();
        editor.remove(context.getString(R.string.user_id)).commit();
        editor.remove(context.getString(R.string.auth_token)).commit();
    }

}
