package com.example.collegebuddy.data;

import android.content.Context;
import android.content.SharedPreferences;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.example.collegebuddy.R;
import com.example.collegebuddy.callback.ServerCallbackJSONArray;
import com.example.collegebuddy.constants.ApplicationConstants;
import com.example.collegebuddy.constants.URLConstants;
import com.example.collegebuddy.entities.AssignmentQuestion;
import com.example.collegebuddy.entities.Course;
import com.example.collegebuddy.entities.ObjectiveOption;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class AssignmentQuestionsData {
    public Context context;
    private List<AssignmentQuestion> assignmentQuestionsList;

    public AssignmentQuestionsData(Context context){
        this.context = context;
    }

    public void getAssignmentsQuestions(String assignmentId,
                                        ServerCallbackJSONArray serverCallbackJSONArray){
        assignmentQuestionsList = new ArrayList<>();
        RequestQueue queue = Volley.newRequestQueue(this.context);
        String url = URLConstants.BASE_URL + ":" + URLConstants.ASSIGNMENT_PORT +
                "/" + URLConstants.ASSIGNMENT_ROUTE + "/"
                + URLConstants.GET_ASSIGNMENT_QUESTION_END_POINT;
        JSONObject postData = new JSONObject();
        try {
            postData.put("assignment_id", assignmentId);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        JsonObjectRequest stringRequest = new JsonObjectRequest(Request.Method.POST, url, postData,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        // Display the first 500 characters of the response string.
                        try {
                            JSONArray array = response.getJSONArray("questions");
                            for (int i = 0; i < array.length(); i++) {
                                JSONObject questionObj = array.getJSONObject(i);
                                AssignmentQuestion question = new AssignmentQuestion();
                                question.setAssignmentId(assignmentId);
                                question.setQuestionId(questionObj.getString("question_id"));
                                question.setQuestion_description(questionObj.getString("question_description"));
                                question.setQuestion_marks(questionObj.getString("question_marks"));
                                question.setQuestion_file_path(questionObj.getString("question_file_path"));
                                assignmentQuestionsList.add(question);
                            }
                            serverCallbackJSONArray.onSuccess(assignmentQuestionsList);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        }
        ){
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();
                params.put("Content-Type", "application/json; charset=UTF-8");
                SharedPreferences sharedPref = context.getSharedPreferences(ApplicationConstants.SHAREDPREF_FILE,
                        context.MODE_PRIVATE);
                String token = sharedPref.getString(context.getString(R.string.auth_token), "");
                params.put("Authorization", token);
                return params;
            }
        };
        queue.add(stringRequest);
    }

    public void saveObjectiveQuestion(JSONObject object,
                                      ServerCallbackJSONArray serverCallbackJSONArray){
        RequestQueue queue = Volley.newRequestQueue(this.context);
        String url = URLConstants.BASE_URL + ":" + URLConstants.ASSIGNMENT_PORT +
                "/" + URLConstants.ASSIGNMENT_ROUTE + "/"
                + URLConstants.ADD_OBJECTIVE_ASSIGNMENT_QUESTION_END_POINT;
        JSONObject payload = new JSONObject();
        try {
            payload.put("payload", object);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        System.out.println(payload);
        JsonObjectRequest stringRequest = new JsonObjectRequest(Request.Method.POST, url, payload,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        System.out.println(response);
                        // Display the first 500 characters of the response string.
                        try {
                            if (response.getString("response").equals("SUCCESS")){
                                serverCallbackJSONArray.onSuccess(null);
                            }else{
                                Toast.makeText(context, response.getString("message"), Toast.LENGTH_SHORT).show();
                            }
                        } catch (JSONException e) {
                            Toast.makeText(context, e.getMessage(), Toast.LENGTH_SHORT).show();
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        }
        ){
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();
                params.put("Content-Type", "application/json; charset=UTF-8");
                SharedPreferences sharedPref = context.getSharedPreferences(ApplicationConstants.SHAREDPREF_FILE,
                        context.MODE_PRIVATE);
                String token = sharedPref.getString(context.getString(R.string.auth_token), "");
                params.put("Authorization", token);
                return params;
            }
        };
        queue.add(stringRequest);
    }

    public void getObjectiveAssignmentsQuestions(String assignmentId,
                                        ServerCallbackJSONArray serverCallbackJSONArray){
        assignmentQuestionsList = new ArrayList<>();
        RequestQueue queue = Volley.newRequestQueue(this.context);
        String url = URLConstants.BASE_URL + ":" + URLConstants.ASSIGNMENT_PORT +
                "/" + URLConstants.ASSIGNMENT_ROUTE + "/"
                + URLConstants.GET_OBJECTIVE_ASSIGNMENT_QUESTION_END_POINT;
        JSONObject postData = new JSONObject();
        try {
            postData.put("assignment_id", assignmentId);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        JsonObjectRequest stringRequest = new JsonObjectRequest(Request.Method.POST, url, postData,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        // Display the first 500 characters of the response string.
                        try {
                            JSONArray array = response.getJSONArray("questions");
                            JSONObject optionsObj = response.getJSONObject("options");
                            for (int i = 0; i < array.length(); i++) {
                                JSONObject questionObj = array.getJSONObject(i);
                                AssignmentQuestion question = new AssignmentQuestion();
                                question.setAssignmentId(assignmentId);
                                question.setQuestionId(questionObj.getString("question_id"));
                                question.setQuestion_description(questionObj.getString("question_description"));
                                question.setQuestion_marks(questionObj.getString("question_marks"));
                                question.setQuestion_file_path(questionObj.getString("question_file_path"));
                                question.setCorrectOption(questionObj.getString("solution"));
                                JSONArray optionArray = optionsObj.getJSONArray(questionObj.getString("question_id"));
                                List<ObjectiveOption> optionList = new ArrayList<>();
                                for (int j = 0; j < optionArray.length(); j++) {
                                    optionList.add(new ObjectiveOption(optionArray.getJSONObject(j).getString("option_id"),
                                            optionArray.getJSONObject(j).getString("option_desc")));
                                }
                                question.setOptions(optionList);
                                 assignmentQuestionsList.add(question);
                            }
                            serverCallbackJSONArray.onSuccess(assignmentQuestionsList);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        }
        ){
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();
                params.put("Content-Type", "application/json; charset=UTF-8");
                SharedPreferences sharedPref = context.getSharedPreferences(ApplicationConstants.SHAREDPREF_FILE,
                        context.MODE_PRIVATE);
                String token = sharedPref.getString(context.getString(R.string.auth_token), "");
                params.put("Authorization", token);
                return params;
            }
        };
        queue.add(stringRequest);
    }

}
