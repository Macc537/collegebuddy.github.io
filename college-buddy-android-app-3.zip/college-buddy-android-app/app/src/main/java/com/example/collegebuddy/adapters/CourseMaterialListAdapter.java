package com.example.collegebuddy.adapters;

import android.app.DownloadManager;
import android.content.Context;
import android.net.Uri;
import android.os.Environment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.collegebuddy.R;
import com.example.collegebuddy.entities.CourseSubjectMaterial;

import java.util.List;

public class CourseMaterialListAdapter extends RecyclerView.Adapter<CourseMaterialListAdapter.ViewHolder> {

    private List<CourseSubjectMaterial> courseSubjectMaterialsList;
    private Context context;
    DownloadManager manager;

    public CourseMaterialListAdapter(List<CourseSubjectMaterial> listdata) {
        this.courseSubjectMaterialsList = listdata;
    }

    public CourseMaterialListAdapter(List<CourseSubjectMaterial> listdata, Context context) {
        this.courseSubjectMaterialsList = listdata;
        this.context = context;
        manager = (DownloadManager) context.getSystemService(Context.DOWNLOAD_SERVICE);

    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View listItem = layoutInflater.inflate(R.layout.course_material_card,
                parent, false);
        ViewHolder viewHolder = new ViewHolder(listItem);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        final CourseSubjectMaterial courseSubjectMaterial = courseSubjectMaterialsList.get(position);
        holder.textViewCourseName.setText(" ("+courseSubjectMaterial.getCourse().getCourseName()+")");
        holder.textViewSubjectName.setText(courseSubjectMaterial.getSubject().getSubjectName());
        holder.textViewTopicName.setText(courseSubjectMaterial.getTopicName());
        holder.textViewTopicDescription.setText(courseSubjectMaterial.getTopicDescription());
        holder.textViewTopicRemarks.setText(courseSubjectMaterial.getTopicRemarks());
        holder.textViewTopicUploadTime.setText(courseSubjectMaterial.getCreatedTime());
        //holder.textViewTopicUploadFile.setText(courseSubjectMaterial.getTopicNotesPath());
        holder.imageButtonDownloadNotes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d("URL", courseSubjectMaterial.getTopicNotesPath());
                Uri uri = Uri.parse(courseSubjectMaterial.getTopicNotesPath());
                DownloadManager.Request request = new DownloadManager.Request(uri);

                request.allowScanningByMediaScanner();
                //request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE);
                request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                request.setVisibleInDownloadsUi(true);
                request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS,
                        courseSubjectMaterial.getCourseSubjectId()+"-" +courseSubjectMaterial.getTopicName() + ".pdf");
                manager.enqueue(request);
                Log.d("Download", "DONE");
            }
        });
    }

    @Override
    public int getItemCount() {
        return courseSubjectMaterialsList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public TextView textViewCourseName;
        public TextView textViewSubjectName;
        public TextView textViewTopicName;
        public TextView textViewTopicDescription;
        public TextView textViewTopicRemarks;
        public TextView textViewTopicUploadTime;
        //public TextView textViewTopicUploadFile;
        public ImageButton imageButtonDownloadNotes;

        public ViewHolder(View itemView) {
            super(itemView);
            this.textViewCourseName = (TextView) itemView.findViewById(R.id.textViewCourseName);
            this.textViewSubjectName = (TextView) itemView.findViewById(R.id.textViewSubjectName);
            this.textViewTopicName = (TextView) itemView.findViewById(R.id.textViewTopicName);
            this.textViewTopicDescription = (TextView) itemView.findViewById(R.id.textViewTopicDescription);
            this.textViewTopicRemarks = (TextView) itemView.findViewById(R.id.textViewTopicRemarks);
            this.textViewTopicUploadTime = (TextView) itemView.findViewById(R.id.textViewTopicUploadTime);
            //this.textViewTopicUploadFile = (TextView) itemView.findViewById(R.id.textViewTopicFilePath);
            this.imageButtonDownloadNotes = (ImageButton) itemView.findViewById(R.id.imageButtonDownloadNotes);

        }
    }

}
