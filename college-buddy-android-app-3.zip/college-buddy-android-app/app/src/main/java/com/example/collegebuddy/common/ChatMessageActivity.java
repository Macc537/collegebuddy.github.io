package com.example.collegebuddy.common;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Toast;

import com.example.collegebuddy.R;
import com.example.collegebuddy.callback.ServerCallbackJSONArray;
import com.example.collegebuddy.common.adapters.ChatListAdapter;
import com.example.collegebuddy.common.adapters.ChatMessagesAdapter;
import com.example.collegebuddy.common.data.ChatData;
import com.example.collegebuddy.common.entities.Chat;
import com.example.collegebuddy.constants.ApplicationConstants;

import java.util.ArrayList;
import java.util.List;

public class ChatMessageActivity extends AppCompatActivity {

    private String user_id;
    private String sender_id;
    private String receiver_id;
    ChatMessagesAdapter chatMessagesAdapter;


    private RecyclerView chatListRecyclerView;

    List<Chat> chatLists = new ArrayList<>();

    private ChatData chatData ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat_message);
        SharedPreferences sharedPref = getSharedPreferences(ApplicationConstants.SHAREDPREF_FILE,
                MODE_PRIVATE);
        user_id = sharedPref.getString(getString(R.string.user_id), "");

        Intent intent = getIntent();
        sender_id = intent.getStringExtra("sender");
        receiver_id = intent.getStringExtra("receiver");


        chatData = new ChatData(getApplicationContext());
        chatListRecyclerView = findViewById(R.id.recyclerViewChatMessages);
        chatListRecyclerView.setHasFixedSize(true);
        chatListRecyclerView.setLayoutManager(new LinearLayoutManager(getApplicationContext()));

    }


    @Override
    public void onResume() {
        chatData.getChatsForSenderReceiver(sender_id, receiver_id, new ServerCallbackJSONArray() {
            @Override
            public void onSuccess(List result) {
                chatLists = result;
                chatMessagesAdapter = new ChatMessagesAdapter(chatLists, getApplicationContext());
                chatListRecyclerView.setAdapter(chatMessagesAdapter);
            }
        });
        super.onResume();
    }
}