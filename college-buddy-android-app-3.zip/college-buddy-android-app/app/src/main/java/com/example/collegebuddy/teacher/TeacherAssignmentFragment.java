package com.example.collegebuddy.teacher;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import com.example.collegebuddy.R;
import com.example.collegebuddy.adapters.AssignmentListAdapter;
import com.example.collegebuddy.adapters.CourseMaterialListAdapter;
import com.example.collegebuddy.callback.ServerCallbackJSONArray;
import com.example.collegebuddy.constants.ApplicationConstants;
import com.example.collegebuddy.data.AssignmentData;
import com.example.collegebuddy.data.SubjectTopicsData;
import com.example.collegebuddy.entities.Assignment;

import java.util.List;


public class TeacherAssignmentFragment extends Fragment implements View.OnClickListener {

    Button uploadAssignment;
    RecyclerView assignmentRecyclerView;
    AssignmentData assignmentData;
    List<Assignment> assignmentList;
    String teacher_id;
    AssignmentListAdapter adapter;

    public TeacherAssignmentFragment() {
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_teacher_assignment, container, false);

        uploadAssignment = view.findViewById(R.id.buttonAddAssignmentFrag);
        uploadAssignment.setOnClickListener(this);
        assignmentData = new AssignmentData(getContext());
        SharedPreferences sharedPref = getContext().getSharedPreferences(ApplicationConstants.SHAREDPREF_FILE, getContext().MODE_PRIVATE);
        teacher_id = sharedPref.getString(getString(R.string.user_id), "");
        assignmentRecyclerView = (RecyclerView) view.findViewById(R.id.recyclerViewAssignment);
        assignmentRecyclerView.setHasFixedSize(true);
        assignmentRecyclerView.setLayoutManager(new LinearLayoutManager(getContext()));


        return view;
    }

    @Override
    public void onResume() {
        assignmentData.getAssignments(teacher_id, new ServerCallbackJSONArray() {
            @Override
            public void onSuccess(List result) {
                assignmentList = result;
                adapter = new AssignmentListAdapter(assignmentList, getContext());
                assignmentRecyclerView.setAdapter(adapter);
            }
        });
        super.onResume();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.buttonAddAssignmentFrag:
                System.out.println("start Add Assignment activity");
                Intent i = new Intent(getContext(), UploadAssignmentActivity.class);
                startActivity(i);
        }
    }
}