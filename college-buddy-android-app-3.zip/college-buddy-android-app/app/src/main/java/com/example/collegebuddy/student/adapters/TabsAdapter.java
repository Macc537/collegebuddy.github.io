package com.example.collegebuddy.student.adapters;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentStatePagerAdapter;

import com.example.collegebuddy.student.OpenAssignmentsFragment;
import com.example.collegebuddy.student.SubmittedAssignmentsFragment;

public class TabsAdapter extends FragmentStatePagerAdapter {
    int mNumOfTabs;

    public TabsAdapter(FragmentManager supportFragmentManager, int tabCount) {
        super(supportFragmentManager);
        this.mNumOfTabs = tabCount;
    }

    @NonNull
    @Override
    public Fragment getItem(int position) {
        switch (position){
            case 0:
                OpenAssignmentsFragment openAssignmentsFragment = new OpenAssignmentsFragment();
                return openAssignmentsFragment;
            case 1:
                SubmittedAssignmentsFragment submittedAssignmentsFragment = new SubmittedAssignmentsFragment();
                return submittedAssignmentsFragment;
            default:
                return null;
        }
    }

    @Override
    public int getCount() {
        return mNumOfTabs;
    }
}
