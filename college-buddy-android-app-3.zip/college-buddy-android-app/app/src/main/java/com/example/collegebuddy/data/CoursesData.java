package com.example.collegebuddy.data;

import android.content.Context;
import android.content.SharedPreferences;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.collegebuddy.R;
import com.example.collegebuddy.callback.ServerCallbackJSONArray;
import com.example.collegebuddy.constants.ApplicationConstants;
import com.example.collegebuddy.constants.URLConstants;
import com.example.collegebuddy.entities.Course;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CoursesData {
    public Context context;
    private List<Course> courses;

    public CoursesData(Context context){
        this.context = context;
    }

    public void getTeacherCourses(String teacher,
                                  ServerCallbackJSONArray serverCallbackJSONArray){
        courses = new ArrayList<>();
        RequestQueue queue = Volley.newRequestQueue(this.context);
        String url = URLConstants.BASE_URL + ":" + URLConstants.COURSE_SUBJECT_PORT +
                "/" + URLConstants.COURSE_SUBJECT_ROUTE + "/"
                + URLConstants.GET_TEACHER_COURSES_END_POINT;
        JSONObject postData = new JSONObject();
        try {
            postData.put("teacher_id", teacher);
            postData.put("session_year", ApplicationConstants.SESSION_YEAR);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        JsonObjectRequest stringRequest = new JsonObjectRequest(Request.Method.POST, url, postData,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        // Display the first 500 characters of the response string.
                        try {

                            JSONArray array = response.getJSONArray("courses");
                            for (int i = 0; i < array.length(); i++) {
                                JSONObject course = array.getJSONObject(i);
                                courses.add(new Course(course.getString("course_id"),
                                        course.getString("course_name")));
                            }
                            serverCallbackJSONArray.onSuccess(courses);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        }
        ){
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();
                params.put("Content-Type", "application/json; charset=UTF-8");
                SharedPreferences sharedPref = context.getSharedPreferences(ApplicationConstants.SHAREDPREF_FILE,
                        context.MODE_PRIVATE);
                String token = sharedPref.getString(context.getString(R.string.auth_token), "");
                params.put("Authorization", token);
                return params;
            }
        };
        queue.add(stringRequest);
    }

    public void loadCourses(ServerCallbackJSONArray serverCallbackJSONArray){
        courses = new ArrayList<>();
        RequestQueue queue = Volley.newRequestQueue(this.context);
        String url = URLConstants.BASE_URL + ":" + URLConstants.COURSE_SUBJECT_PORT +
                "/" + URLConstants.COURSE_SUBJECT_ROUTE + "/"
                + URLConstants.GET_COURSES_END_POINT;

        // Request a string response from the provided URL.
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        // Display the first 500 characters of the response string.
                        try {
                            JSONObject obj = new JSONObject(response);
                            JSONArray array = new JSONArray(obj.getString("courses"));
                            for (int i = 0; i < array.length(); i++) {
                                JSONObject course = array.getJSONObject(i);
                                courses.add(new Course(course.getString("course_id"),
                                        course.getString("course_name")));
                            }
                            serverCallbackJSONArray.onSuccess(courses);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        }
        ){
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();
                params.put("Content-Type", "application/json; charset=UTF-8");
                SharedPreferences sharedPref = context.getSharedPreferences(ApplicationConstants.SHAREDPREF_FILE,
                        context.MODE_PRIVATE);
                String token = sharedPref.getString(context.getString(R.string.auth_token), "");
                params.put("Authorization", token);
                return params;
            }
        };
        queue.add(stringRequest);
    }

}
