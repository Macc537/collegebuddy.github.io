package com.example.collegebuddy.callback;

import org.json.JSONArray;

import java.util.List;

public interface ServerCallbackJSONArray {
    void onSuccess(List result);
}
