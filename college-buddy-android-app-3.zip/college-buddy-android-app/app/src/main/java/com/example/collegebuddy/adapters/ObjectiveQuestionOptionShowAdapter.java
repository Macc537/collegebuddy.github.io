package com.example.collegebuddy.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.collegebuddy.R;
import com.example.collegebuddy.entities.ObjectiveOption;

import java.util.List;

public class ObjectiveQuestionOptionShowAdapter extends RecyclerView.Adapter<ObjectiveQuestionOptionShowAdapter.ViewHolder>{

    private List<ObjectiveOption> objectiveOptionList;


    public ObjectiveQuestionOptionShowAdapter(List<ObjectiveOption> listData) {
        this.objectiveOptionList = listData;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View listItem = layoutInflater.inflate(R.layout.show_objective_question_card,
                parent, false);
        ObjectiveQuestionOptionShowAdapter.ViewHolder viewHolder = new ObjectiveQuestionOptionShowAdapter.ViewHolder(listItem);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        final ObjectiveOption objectiveOption = objectiveOptionList.get(position);
        holder.textViewOptionKey.setText(objectiveOption.getOptionKey()+".");
        holder.textViewOptionVal.setText(objectiveOption.getOptionValue());
    }

    @Override
    public int getItemCount() {
        return objectiveOptionList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public TextView textViewOptionKey;
        public TextView textViewOptionVal;

        public ViewHolder(View itemView) {
            super(itemView);
            this.textViewOptionKey = (TextView) itemView.findViewById(R.id.textViewOptionKey);
            this.textViewOptionVal = (TextView) itemView.findViewById(R.id.textViewOptionVal);
        }
    }
}
