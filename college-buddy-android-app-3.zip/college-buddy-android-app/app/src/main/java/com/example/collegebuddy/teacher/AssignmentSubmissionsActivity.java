package com.example.collegebuddy.teacher;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import com.example.collegebuddy.R;
import com.example.collegebuddy.adapters.AssignmentQuestionsListAdapter;
import com.example.collegebuddy.adapters.AssignmentSubmissionAdapter;
import com.example.collegebuddy.callback.ServerCallbackJSONArray;
import com.example.collegebuddy.data.AssignmentData;
import com.example.collegebuddy.data.AssignmentSubmissionsData;
import com.example.collegebuddy.entities.AssignmentSubmission;

import java.util.ArrayList;
import java.util.List;

public class AssignmentSubmissionsActivity extends AppCompatActivity {
    String assignment_id, assignmentName, assignmentType;
    RecyclerView recyclerViewAssignmentSubmissions;
    TextView textViewAssignmentName;
    AssignmentSubmissionsData assignmentSubmissionsData;
    List<AssignmentSubmission> assignmentSubmissionList = new ArrayList<>();
    AssignmentSubmissionAdapter assignmentSubmissionAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_assignment_submissions);

        assignmentSubmissionsData = new AssignmentSubmissionsData(getApplicationContext());

        Intent intent = getIntent();
        assignment_id = intent.getStringExtra("assignment_id");
        assignmentName = intent.getStringExtra("assignmentName");
        assignmentType = intent.getStringExtra("assignmentType");

        textViewAssignmentName = findViewById(R.id.textviewassignmentName);
        textViewAssignmentName.setText(assignmentName);

        recyclerViewAssignmentSubmissions = findViewById(R.id.recyclerViewAssignmentSubmissions);

        assignmentSubmissionsData.getAssignmentsSubmissions(assignment_id, new ServerCallbackJSONArray() {
            @Override
            public void onSuccess(List result) {
                assignmentSubmissionList = result;

                assignmentSubmissionAdapter = new AssignmentSubmissionAdapter(assignmentSubmissionList,
                        getApplicationContext());
                recyclerViewAssignmentSubmissions.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
                recyclerViewAssignmentSubmissions.setAdapter(assignmentSubmissionAdapter);
            }
        });





    }
}