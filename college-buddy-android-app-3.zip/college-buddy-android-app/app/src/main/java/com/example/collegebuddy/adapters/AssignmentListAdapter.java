package com.example.collegebuddy.adapters;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.collegebuddy.R;
import com.example.collegebuddy.callback.ServerCallbackJSONArray;
import com.example.collegebuddy.constants.ApplicationConstants;
import com.example.collegebuddy.data.AssignmentData;
import com.example.collegebuddy.entities.Assignment;
import com.example.collegebuddy.teacher.AssignmentSubmissionsActivity;
import com.example.collegebuddy.teacher.UploadObjectiveAssignmentQuestionsActivity;
import com.example.collegebuddy.teacher.UploadSubjectiveAssignmentQuestionsActivity;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.List;


public class AssignmentListAdapter extends RecyclerView.Adapter<AssignmentListAdapter.ViewHolder> {

    private List<Assignment> assignmentList;
    private Context context;
    private AssignmentData assignmentData;

    public AssignmentListAdapter(List<Assignment> listData) {
        this.assignmentList = listData;
    }

    public AssignmentListAdapter(List<Assignment> assignmentList, Context context) {
        this.assignmentList = assignmentList;
        this.context = context;
        this.assignmentData = new AssignmentData(context);
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View listItem = layoutInflater.inflate(R.layout.assignment_card,
                parent, false);
        AssignmentListAdapter.ViewHolder viewHolder = new AssignmentListAdapter.ViewHolder(listItem);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, @SuppressLint("RecyclerView") int position) {
        final Assignment assignment = assignmentList.get(position);
        holder.textViewCourseName.setText(" ("+assignment.getCourse().getCourseName()+")");
        holder.textViewSubjectName.setText(assignment.getSubject().getSubjectName());
        holder.textViewAssignmentName.setText(assignment.getAssignmentName());
        holder.textViewAssignmentDescription.setText(assignment.getAssignmentDescription());
        holder.textViewAssignmentDue.setText("Due By - " + assignment.getAssignmentDue());
        holder.textViewAssignmentStartTime.setText("Start Time -" + assignment.getStartTime());
        holder.textViewAssignmentUploadTime.setText(assignment.getCreatedTime());
        holder.textViewAssignmentType.setText(assignment.getAssignmentType());

        holder.editAssignmentButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = null;
                Toast.makeText(context, assignment.getAssignmentType(), Toast.LENGTH_SHORT).show();
                if (assignment.getAssignmentType().equals(ApplicationConstants.SUBJECTIVE_ASSIGNMENT)){
                    intent = new Intent(context, UploadSubjectiveAssignmentQuestionsActivity.class);
                }else {
                    intent = new Intent(context, UploadObjectiveAssignmentQuestionsActivity.class);
                }
                intent.putExtra("assignment_id", assignment.getAssignmentId());
                intent.putExtra("assignmentName", assignment.getAssignmentName());
                intent.putExtra("course_subject_id", assignment.getCourseSubjectId());
                context.startActivity(intent);
            }
        });

        holder.completeAssignmentButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                JSONObject object = new JSONObject();
                try {
                    object.put("assignment_id", assignment.getAssignmentId());
                    object.put("status", ApplicationConstants.ASSIGNMENT_STATUS_COMPLETE);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                assignmentData.updateAssignmentsData(object, new ServerCallbackJSONArray() {
                    @Override
                    public void onSuccess(List result) {
                        assignmentList.remove(position);
                        notifyItemRemoved(position);
                    }
                });

            }
        });

        holder.submissionAssignmentButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, AssignmentSubmissionsActivity.class);
                intent.putExtra("assignment_id", assignment.getAssignmentId());
                intent.putExtra("assignmentName", assignment.getAssignmentName());
                intent.putExtra("course_subject_id", assignment.getCourseSubjectId());
                intent.putExtra("assignmentType", assignment.getAssignmentType());
                context.startActivity(intent);
            }
        });

        holder.deleteAssignmentButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                JSONObject object = new JSONObject();
                try {
                    object.put("assignment_id", assignment.getAssignmentId());
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                assignmentData.deleteAssignments(object, new ServerCallbackJSONArray() {
                    @Override
                    public void onSuccess(List result) {
                        assignmentList.remove(position);
                        notifyItemRemoved(position);
                    }
                });
            }
        });
    }

    @Override
    public int getItemCount() {
        return assignmentList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public TextView textViewCourseName;
        public TextView textViewSubjectName;
        public TextView textViewAssignmentName;
        public TextView textViewAssignmentDescription;
        public TextView textViewAssignmentDue;
        public TextView textViewAssignmentStartTime;
        public TextView textViewAssignmentUploadTime;
        public TextView textViewAssignmentType;

        public ImageButton editAssignmentButton;
        public ImageButton submissionAssignmentButton;
        public ImageButton deleteAssignmentButton;
        public ImageButton completeAssignmentButton;



        public ViewHolder(View itemView) {
            super(itemView);
            this.textViewCourseName = (TextView) itemView.findViewById(R.id.textViewAssignmentCourseName);
            this.textViewSubjectName = (TextView) itemView.findViewById(R.id.textViewAssignmentSubjectName);
            this.textViewAssignmentName = (TextView) itemView.findViewById(R.id.textViewAssignmentName);
            this.textViewAssignmentDescription = (TextView) itemView.findViewById(R.id.textViewAssignmentDescription);
            this.textViewAssignmentDue = (TextView) itemView.findViewById(R.id.textViewAssignmentDue);
            this.textViewAssignmentStartTime = (TextView) itemView.findViewById(R.id.textViewAssignmentStartTime);
            this.textViewAssignmentUploadTime = (TextView) itemView.findViewById(R.id.textViewAssignmentUploadTime);
            this.textViewAssignmentType = (TextView) itemView.findViewById(R.id.textViewAssignmentType);

            this.editAssignmentButton = (ImageButton) itemView.findViewById(R.id.buttonEditAssignmentQuestions);
            this.submissionAssignmentButton = (ImageButton) itemView.findViewById(R.id.buttonCheckAssignment);
            this.deleteAssignmentButton = (ImageButton) itemView.findViewById(R.id.buttonDeleteAssignment);
            this.completeAssignmentButton = (ImageButton) itemView.findViewById(R.id.buttonCompleteCheckAssignment);
        }
    }

}
