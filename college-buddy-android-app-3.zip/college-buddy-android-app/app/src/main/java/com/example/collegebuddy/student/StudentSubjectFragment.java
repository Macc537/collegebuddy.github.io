package com.example.collegebuddy.student;

import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager.widget.ViewPager;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.collegebuddy.R;
import com.example.collegebuddy.adapters.CourseMaterialListAdapter;
import com.example.collegebuddy.callback.ServerCallbackJSONArray;
import com.example.collegebuddy.constants.ApplicationConstants;
import com.example.collegebuddy.data.SubjectTopicsData;
import com.example.collegebuddy.entities.CourseSubjectMaterial;
import com.example.collegebuddy.student.adapters.TabsAdapter;
import com.google.android.material.tabs.TabLayout;

import java.util.ArrayList;
import java.util.List;


public class StudentSubjectFragment extends Fragment {
    RecyclerView recyclerView;
    private SubjectTopicsData subjectTopicsData ;
    List<CourseSubjectMaterial> courseSubjectMaterials = new ArrayList<>();

    public StudentSubjectFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view =  inflater.inflate(R.layout.fragment_student_subject, container, false);

        subjectTopicsData = new SubjectTopicsData(getContext());

        SharedPreferences sharedPref = getContext().getSharedPreferences(ApplicationConstants.SHAREDPREF_FILE,
                getContext().MODE_PRIVATE);
        String user_id = sharedPref.getString(getString(R.string.user_id), "");



        recyclerView = (RecyclerView) view.findViewById(R.id.recyclerViewCourseSubjectMaterial);

        subjectTopicsData.getSubjectTopicsStudent(user_id, new ServerCallbackJSONArray() {
            @Override
            public void onSuccess(List result) {
                courseSubjectMaterials = result;
                CourseMaterialListAdapter adapter = new CourseMaterialListAdapter(courseSubjectMaterials, getActivity());
                recyclerView.setHasFixedSize(true);
                recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
                recyclerView.setAdapter(adapter);
            }
        });

        return view;
    }
}