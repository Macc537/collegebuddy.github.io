package com.example.collegebuddy.entities;

public class CourseSubjectTeacher {

    String teacherId;
    String courseSubjectId;
    String subjectName;

    public CourseSubjectTeacher(String teacherId, String courseSubjectId, String subjectName) {
        this.teacherId = teacherId;
        this.courseSubjectId = courseSubjectId;
        this.subjectName = subjectName;
    }

    public CourseSubjectTeacher(){

    }

    public String getTeacherId() {
        return teacherId;
    }

    public void setTeacherId(String teacherId) {
        this.teacherId = teacherId;
    }

    public String getCourseSubjectId() {
        return courseSubjectId;
    }

    public void setCourseSubjectId(String courseSubjectId) {
        this.courseSubjectId = courseSubjectId;
    }

    public String getSubjectName() {
        return subjectName;
    }

    public void setSubjectName(String subjectName) {
        this.subjectName = subjectName;
    }

    //to display object as a string in spinner
    @Override
    public String toString() {
        return getSubjectName();
    }
}
