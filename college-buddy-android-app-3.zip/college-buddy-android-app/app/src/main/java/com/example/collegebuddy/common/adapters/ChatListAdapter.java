package com.example.collegebuddy.common.adapters;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.collegebuddy.R;
import com.example.collegebuddy.callback.ServerCallbackJSONArray;
import com.example.collegebuddy.common.ChatMessageActivity;
import com.example.collegebuddy.common.entities.Chat;
import com.example.collegebuddy.constants.ApplicationConstants;
import com.example.collegebuddy.data.AssignmentData;
import com.example.collegebuddy.entities.Assignment;
import com.example.collegebuddy.teacher.AssignmentSubmissionsActivity;
import com.example.collegebuddy.teacher.UploadObjectiveAssignmentQuestionsActivity;
import com.example.collegebuddy.teacher.UploadSubjectiveAssignmentQuestionsActivity;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.List;


public class ChatListAdapter extends RecyclerView.Adapter<ChatListAdapter.ViewHolder> {

    private List<Chat> chatList;
    private Context context;
    private AssignmentData assignmentData;

    public ChatListAdapter(List<Chat> listData) {
        this.chatList = listData;
    }

    public ChatListAdapter(List<Chat> chatList, Context context) {
        this.chatList = chatList;
        this.context = context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View listItem = layoutInflater.inflate(R.layout.chat_card,
                parent, false);
        ChatListAdapter.ViewHolder viewHolder = new ChatListAdapter.ViewHolder(listItem);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, @SuppressLint("RecyclerView") int position) {
        final Chat chat = chatList.get(position);
        holder.textViewChatSender.setText(chat.getSender());
        holder.textViewChatTimestamp.setText(chat.getTimestamp());
        holder.textViewChatMsg.setText(chat.getMessage());

        holder.linearLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, ChatMessageActivity.class);
                intent.putExtra("sender", chat.getSender());
                intent.putExtra("receiver", chat.getReceiver());
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);

                context.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return chatList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public TextView textViewChatSender;
        public TextView textViewChatTimestamp;
        public TextView textViewChatMsg;
        public LinearLayout linearLayout;

        public ViewHolder(View itemView) {
            super(itemView);
            this.textViewChatSender = (TextView) itemView.findViewById(R.id.textViewChatSender);
            this.textViewChatTimestamp = (TextView) itemView.findViewById(R.id.textViewChatTimestamp);
            this.textViewChatMsg = (TextView) itemView.findViewById(R.id.textViewChatMsg);
            this.linearLayout = itemView.findViewById(R.id.linearLayoutChat);
        }
    }

}
