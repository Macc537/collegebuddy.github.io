package com.example.collegebuddy.adapters;

import android.app.DownloadManager;
import android.content.Context;
import android.net.Uri;
import android.os.Environment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.lifecycle.ViewModel;
import androidx.recyclerview.widget.RecyclerView;

import com.example.collegebuddy.R;
import com.example.collegebuddy.entities.Assignment;
import com.example.collegebuddy.entities.AssignmentQuestion;

import java.util.List;

public class AssignmentQuestionsListAdapter  extends RecyclerView.Adapter<AssignmentQuestionsListAdapter.ViewHolder> {

    private List<AssignmentQuestion> assignmentQuestionsList;
    private Context context;
    DownloadManager manager;

    public AssignmentQuestionsListAdapter(List<AssignmentQuestion> listData) {
        this.assignmentQuestionsList = listData;
    }

    public AssignmentQuestionsListAdapter(List<AssignmentQuestion> assignmentQuestionsList, Context context) {
        this.assignmentQuestionsList = assignmentQuestionsList;
        this.context = context;
        manager = (DownloadManager) context.getSystemService(Context.DOWNLOAD_SERVICE);
    }


    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View listItem = layoutInflater.inflate(R.layout.assignment_question_card,
                parent, false);
        AssignmentQuestionsListAdapter.ViewHolder viewHolder = new AssignmentQuestionsListAdapter.ViewHolder(listItem);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        final AssignmentQuestion assignmentQuestion = assignmentQuestionsList.get(position);
        holder.textViewQuestionId.setText(assignmentQuestion.getQuestionId()+". ");
        holder.textViewQuestionDesc.setText(assignmentQuestion.getQuestion_description());
        holder.textViewQuestionMarks.setText(assignmentQuestion.getQuestion_marks());
        holder.imageButtonDownload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d("URL", assignmentQuestion.getQuestion_file_path());
                Uri uri = Uri.parse(assignmentQuestion.getQuestion_file_path());
                DownloadManager.Request request = new DownloadManager.Request(uri);

                request.allowScanningByMediaScanner();
                //request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE);
                request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                request.setVisibleInDownloadsUi(true);
//                request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS,
//                        assignmentQuestion.getAssignmentId() +"-Q" + assignmentQuestion.getQuestionId() + ".pdf");
                manager.enqueue(request);
                Log.d("Download", "DONE");
            }
        });

    }

    public void addItem(int position, AssignmentQuestion viewModel) {
        assignmentQuestionsList.add(position, viewModel);
        notifyItemInserted(position);
    }


    @Override
    public int getItemCount() {
        return assignmentQuestionsList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public TextView textViewQuestionId;
        public TextView textViewQuestionDesc;
        public TextView textViewQuestionMarks;
        public ImageButton imageButtonDownload;
        public TextView textViewMarksReceived;


        public ViewHolder(View itemView) {
            super(itemView);
            this.textViewQuestionId = (TextView) itemView.findViewById(R.id.textViewQuestionId);
            this.textViewQuestionDesc = (TextView) itemView.findViewById(R.id.textViewQuestionDescription);
            this.textViewQuestionMarks = (TextView) itemView.findViewById(R.id.textViewQuestionMarks);
            this.imageButtonDownload = (ImageButton) itemView.findViewById(R.id.imageButtonDownload);
            this.textViewMarksReceived = (TextView) itemView.findViewById(R.id.textViewMarksReceived);

        }
    }


}
