package com.example.collegebuddy.constants;


public  class URLConstants {

    public static String BASE_URL = "http://18.132.40.184";
   // public static String BASE_URL = "http://10.0.2.2";



    public static Integer AUTH_PORT = 3001;
    public static Integer USERS_ROLES_PORT = 3002;
    public static Integer COURSE_SUBJECT_PORT = 3003;
    public static Integer ASSIGNMENT_PORT = 3004;
    public static Integer POST_PORT = 3005;
    public static Integer CHAT_PORT = 3006;


    public static String AUTH_ROUTE = "v1/api/auth";
    public static String USER_ROLES_ROUTE = "v1/api/users";
    public static String COURSE_SUBJECT_ROUTE = "v1/api/courses";
    public static String ASSIGNMENT_ROUTE = "v1/api/assignment";
    public static String POST_ROUTE = "v1/api/posts";
    public static String CHAT_ROUTE = "v1/api/chat";




    public static String LOGIN_END_POINT = "login";
    public static String UPDATE_PASSWORD_END_POINT = "update_password";

    public static String ADD_USER_END_POINT = "add_users";
    public static String GET_TEACHERS_END_POINT = "get_teachers";

    public static String ADD_COURSE_END_POINT = "add_courses";
    public static String ADD_SUBJECT_END_POINT = "add_subjects";
    public static String GET_COURSES_END_POINT = "get_courses";
    public static String GET_SUBJECTS_END_POINT = "get_subjects";
    public static String GET_TEACHER_SUBJECTS_END_POINT = "get_teacher_subjects";
    public static String GET_TEACHER_COURSES_END_POINT = "get_teacher_courses";
    public static String GET_TEACHER_SUBJECTS_TOPICS_END_POINT = "get_course_material";
    public static String ADD_COURSE_SUBJECT_MAPPING_END_POINT = "add_course_subjects_mapping";
    public static String GET_COURSE_SUBJECT_MAPPING_END_POINT = "get_course_subjects_mapping";

    public static String GET_TEACHER_MAPPED_SUBJECTS_END_POINT = "get_teacher_mapped_subjects";
    public static String GET_STUDENTS_SUBJECTS_TOPICS_END_POINT = "get_students_course_material";
    public static String UPLOAD_SUBJECTS_NOTES_END_POINT = "upload_course_material";
    public static String ADD_SUBJECTS_NOTES_END_POINT = "add_course_material";
    public static String UPLOAD_STUDENT_SUBJECTS_END_POINT = "upload_students_subjects";





    public static String ADD_ASSIGNMENT_END_POINT = "add_assignments";
    public static String GET_TEACHER_ASSIGNMENTS_END_POINT = "get_assignments";
    public static String GET_STUDENT_ASSIGNMENTS_END_POINT = "get_student_assignments";
    public static String GET_STUDENT_SUBMITTED_ASSIGNMENTS_END_POINT = "get_student_submitted_assignments";


    public static String ADD_ASSIGNMENT_QUESTION_END_POINT = "add_assignment_questions";
    public static String GET_ASSIGNMENT_QUESTION_END_POINT = "get_assignment_questions";
    public static String ADD_OBJECTIVE_ASSIGNMENT_QUESTION_END_POINT = "upload_objective_questions";
    public static String GET_OBJECTIVE_ASSIGNMENT_QUESTION_END_POINT = "get_objective_assignment_questions";
    public static String UPLOAD_SUBJECTIVE_ASSIGNMENT = "upload_assignment";
    public static String UPLOAD_SUBJECTIVE_ASSIGNMENT_SOL = "upload_assignment_solution";


    public static String SUBMIT_ASSIGNMENT_END_POINT = "save_assignment";
    public static String DELETE_ASSIGNMENT_END_POINT = "delete_assignment";
    public static String UPDATE_ASSIGNMENT_END_POINT = "update_assignment";

    public static String GET_ASSIGNMENT_SUBMISSIONS_END_POINT = "get_assignment_submissions";
    public static String GET_STUDENT_SUBMISSIONS_END_POINT = "get_student_submission";

    public static String UPDATE_ASSIGNMENT_SUBMISSION_END_POINT = "update_assignment_submissions";


    public static String GET_POST_FOR_ADMIN_END_POINT = "get_posts_for_admin";
    public static String GET_POST_END_POINT = "get_posts";
    public static String GET_USER_POST_END_POINT = "get_user_posts";

    public static String ADD_POST_END_POINT = "add_post";
    public static String UPDATE_POST_STATUS_END_POINT = "update_post_status";


    public static String CHAT_LIST = "get_messages";
    public static String USER_CHAT_LIST = "get_user_messages";





}
