package com.example.collegebuddy.teacher;

import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.example.collegebuddy.R;
import com.example.collegebuddy.adapters.PostListAdapter;
import com.example.collegebuddy.adapters.PostListViewAdapter;
import com.example.collegebuddy.callback.ServerCallbackJSONArray;
import com.example.collegebuddy.constants.ApplicationConstants;
import com.example.collegebuddy.constants.URLConstants;
import com.example.collegebuddy.data.PostData;
import com.example.collegebuddy.entities.Post;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class TeacherHomeFragment extends Fragment implements View.OnClickListener {

    Button uploadPost;
    RecyclerView recyclerView;
    String teacher_id;
    private PostData postData ;
    List<Post> postList = new ArrayList<>();
    PostListViewAdapter postListAdapter;

    public TeacherHomeFragment() {
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_teacher_home,
                container, false);
        uploadPost = view.findViewById(R.id.buttonTeacherAddPost);
        uploadPost.setOnClickListener(this);
        recyclerView = view.findViewById(R.id.recyclerViewTeacherPostView);
        SharedPreferences sharedPref = getContext().getSharedPreferences(ApplicationConstants.SHAREDPREF_FILE, getContext().MODE_PRIVATE);
        teacher_id = sharedPref.getString(getString(R.string.user_id), "");

        postData = new PostData(getContext());
        return view;
    }

    @Override
    public void onResume() {
        super.onResume();
        postData.getPosts(new ServerCallbackJSONArray() {
            @Override
            public void onSuccess(List result) {
                postList = result;
                postListAdapter = new PostListViewAdapter(postList);
                recyclerView.setHasFixedSize(true);
                recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
                recyclerView.setAdapter(postListAdapter);
            }
        });
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.buttonTeacherAddPost:
                AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
                builder.setTitle("Add Post");
                LayoutInflater layoutInflater = getLayoutInflater();
                final View inflator = layoutInflater.inflate(R.layout.add_post_card, null);

                final EditText editTextPostHeading = (EditText) inflator.findViewById(R.id.editTextPostHeading);
                final EditText editTextPostDescription = (EditText) inflator.findViewById(R.id.editTextPostDescription);
                final EditText editTextPostDueDate = (EditText) inflator.findViewById(R.id.editTextPostDueDate);


                builder.setView(inflator)
                        .setPositiveButton(R.string.add_post, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                String postHead = String.valueOf(editTextPostHeading.getText());
                                String postDesc = String.valueOf(editTextPostDescription.getText());
                                String postDue = String.valueOf(editTextPostDueDate.getText());

                                Map<String, String> data = new HashMap<>();
                                data.put("post_heading",postHead);
                                data.put("post_desc", postDesc);
                                data.put("due_date", postDue);
                                data.put("status", ApplicationConstants.POST_IN_ACTIVE_STATUS);
                                SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
                                Date date = new Date();
                                String createdDate = formatter.format(date);
                                data.put("created_at", createdDate);
                                data.put("posted_by", teacher_id);
                                data.put("post_id", createdDate + "-" + teacher_id);
                                postData.savePostInDB(data, new ServerCallbackJSONArray() {
                                    @Override
                                    public void onSuccess(List result) {
                                        Toast.makeText(getActivity(), "Post Added Successfully, It is with Admin for review", Toast.LENGTH_SHORT).show();
                                    }
                                });
                            }
                        })
                        .setNegativeButton(R.string.cancel, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {

                            }
                        });
                builder.show();
                break;
        }
    }


}