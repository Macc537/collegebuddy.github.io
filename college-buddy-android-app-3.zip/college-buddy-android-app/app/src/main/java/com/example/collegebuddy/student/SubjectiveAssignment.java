package com.example.collegebuddy.student;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.DownloadManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.collegebuddy.R;
import com.example.collegebuddy.adapters.AssignmentQuestionsListAdapter;
import com.example.collegebuddy.callback.ServerCallbackJSONArray;
import com.example.collegebuddy.constants.ApplicationConstants;
import com.example.collegebuddy.constants.URLConstants;
import com.example.collegebuddy.data.AssignmentData;
import com.example.collegebuddy.data.AssignmentQuestionsData;
import com.example.collegebuddy.data.AssignmentSubmissionsData;
import com.example.collegebuddy.entities.AssignmentQuestion;
import com.example.collegebuddy.entities.AssignmentSubmission;
import com.example.collegebuddy.utils.UploadFileUtils;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class SubjectiveAssignment extends AppCompatActivity implements View.OnClickListener {

    private static final int PICK_FILE_REQUEST = 21000;
    Button submitAssignmentBtn, buttonUploadAnswersAssignmentQuestion, buttonAnswersAssignment;
    RecyclerView recyclerViewAssignmentQuestions;
    TextView textViewAssignmentName;
    TextView textViewTotalMarks, textViewMarksReceived;

    String assignment_id, assignmentName, course_subject_id, solFilePath;
    List<AssignmentQuestion> assignmentQuestions;
    AssignmentQuestionsData assignmentQuestionsData;
    AssignmentData assignmentData;
    AssignmentQuestionsListAdapter adapter;
    AssignmentSubmissionsData assignmentSubmissionsData;
    String student_id;
    String isAssignmentSubmitted ;
    AssignmentSubmission assignmentSubmission;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_subjective_assignment);
        SharedPreferences sharedPref =getSharedPreferences(ApplicationConstants.SHAREDPREF_FILE, MODE_PRIVATE);
        student_id = sharedPref.getString(getString(R.string.user_id), "");
        assignmentQuestions = new ArrayList<>();
        assignmentQuestionsData = new AssignmentQuestionsData(getApplicationContext());
        assignmentData = new AssignmentData(getApplicationContext());

        Intent intent = getIntent();
        assignment_id = intent.getStringExtra("assignment_id");
        assignmentName = intent.getStringExtra("assignmentName");
        isAssignmentSubmitted = intent.getStringExtra("is_assignment_submitted");
        course_subject_id = intent.getStringExtra("course_subject_id");
        textViewAssignmentName = findViewById(R.id.textviewassignmentName);
        textViewAssignmentName.setText(assignmentName);

        textViewTotalMarks= findViewById(R.id.textViewTotalMarks);
        textViewMarksReceived= findViewById(R.id.textViewMarksReceived);;

        submitAssignmentBtn = findViewById(R.id.buttonSubmitAssignmentQuestion);
        submitAssignmentBtn.setOnClickListener(this);

        buttonAnswersAssignment = findViewById(R.id.buttonAnswersAssignment);
        buttonAnswersAssignment.setOnClickListener(this);

        buttonUploadAnswersAssignmentQuestion = findViewById(R.id.buttonUploadAnswersAssignmentQuestion);

        if (isAssignmentSubmitted.equals("true")){
            submitAssignmentBtn.setVisibility(View.GONE);
            buttonUploadAnswersAssignmentQuestion.setVisibility(View.GONE);
            assignmentSubmissionsData = new AssignmentSubmissionsData(getApplicationContext());
            JSONObject inputObj = new JSONObject();
            try {
                inputObj.put("student_id", student_id);
                inputObj.put("assignment_id", assignment_id);
            } catch (JSONException e) {
                e.printStackTrace();
            }
            assignmentSubmissionsData.getStudentSubmission(inputObj, new ServerCallbackJSONArray() {
                @Override
                public void onSuccess(List result) {
                    assignmentSubmission = (AssignmentSubmission) result.get(0);
                    if (assignmentSubmission.getMarks().equals("null")){
                        textViewMarksReceived.setVisibility(View.GONE);
                        textViewTotalMarks.setVisibility(View.GONE);
                    }
                    textViewMarksReceived.setText(assignmentSubmission.getMarks()+"/");
                }
            });


        }
        else{
            textViewMarksReceived.setVisibility(View.GONE);
            textViewTotalMarks.setVisibility(View.GONE);
            buttonAnswersAssignment.setVisibility(View.GONE);
        }

        buttonUploadAnswersAssignmentQuestion = findViewById(R.id.buttonUploadAnswersAssignmentQuestion);
        buttonUploadAnswersAssignmentQuestion.setOnClickListener(this);
        recyclerViewAssignmentQuestions = findViewById(R.id.recyclerViewAssignmentQuestions);
        assignmentQuestionsData.getAssignmentsQuestions(assignment_id, new ServerCallbackJSONArray() {
            @Override
            public void onSuccess(List result) {
                assignmentQuestions = result;
                adapter = new AssignmentQuestionsListAdapter(assignmentQuestions, getApplicationContext());
                recyclerViewAssignmentQuestions.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
                recyclerViewAssignmentQuestions.setAdapter(adapter);

                Float marks = Float.valueOf(0);
                for (int i=0; i<assignmentQuestions.size(); i++){
                    AssignmentQuestion question = assignmentQuestions.get(i);
                    marks = marks + Float.valueOf(question.getQuestion_marks());
                }
                textViewTotalMarks.setText(String.valueOf(marks));
            }
        });
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.buttonSubmitAssignmentQuestion:
                JSONObject assignmentObj = new JSONObject();
                try {
                    assignmentObj.put("assignment_type", "subjective");
                    assignmentObj.put("assignment_id", assignment_id);
                    assignmentObj.put("student_id", student_id);
                    assignmentObj.put("submission_file_path", solFilePath);

                } catch (JSONException e) {
                    e.printStackTrace();
                }

                assignmentData.saveAssignmentsStudents(assignmentObj, new ServerCallbackJSONArray() {
                    @Override
                    public void onSuccess(List result) {
                        Toast.makeText(getApplicationContext(),
                                "Assignment Submitted",
                                Toast.LENGTH_SHORT).show();
                        finish();
                    }
                });

                break;
            case R.id.buttonUploadAnswersAssignmentQuestion:

                System.out.println("Select File");
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.setType("application/pdf");
                startActivityForResult(Intent.createChooser(intent, "Select Answer File"), PICK_FILE_REQUEST);
                break;

            case R.id.buttonAnswersAssignment:
                System.out.println("Downloading Answer File");
                DownloadManager manager = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);

                Log.d("URL", assignmentSubmission.getSubmittedFile());
                Uri uri = Uri.parse(assignmentSubmission.getSubmittedFile());
                DownloadManager.Request request = new DownloadManager.Request(uri);

                request.allowScanningByMediaScanner();
                //request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE);
                request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                request.setVisibleInDownloadsUi(true);
                request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS,
                        assignmentSubmission.getAssignment().getAssignmentId() +"-Solution.pdf");
                manager.enqueue(request);
                Log.d("Download", "DONE");
                break;
        }


    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_FILE_REQUEST) {
            if (resultCode == RESULT_OK) {
                Uri uri = data.getData();
                try {
                    String url = URLConstants.BASE_URL + ":" + URLConstants.ASSIGNMENT_PORT +
                            "/" + URLConstants.ASSIGNMENT_ROUTE + "/"
                            + URLConstants.UPLOAD_SUBJECTIVE_ASSIGNMENT_SOL;
                    String fileName =  course_subject_id +  "|" + assignment_id + "|" + student_id;
                    UploadFileUtils.uploadFile(uri, getApplicationContext(), url, fileName, new ServerCallbackJSONArray() {
                        @Override
                        public void onSuccess(List result) {
                            Log.d("Message", String.valueOf(result.get(0)));
                            solFilePath =  String.valueOf(result.get(0));
                            Toast.makeText(getApplicationContext(), "Uploaded Answer Sheet Successfully" ,
                                    Toast.LENGTH_SHORT).show();
                        }
                    });
                } catch (Exception exc) {
                    Toast.makeText(this, exc.getMessage(), Toast.LENGTH_SHORT).show();
                    Log.e("ERROR", exc.getLocalizedMessage());
                    exc.printStackTrace();
                }
            }
        }
    }

}