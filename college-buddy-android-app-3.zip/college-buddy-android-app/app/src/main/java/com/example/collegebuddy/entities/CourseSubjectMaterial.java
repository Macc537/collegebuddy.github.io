package com.example.collegebuddy.entities;

public class CourseSubjectMaterial {

    private String courseSubjectId;
    private String topicDescription;
    private String topicRemarks;
    private String topicNotesPath;
    private Subject subject;
    private Course course;
    private String topicName;
    private String createdTime;

    public CourseSubjectMaterial(){

    }

    public CourseSubjectMaterial(String courseSubjectId,
                                 String topicName,
                                 String topicDescription,
                                 String topicRemarks,
                                 String topicNotesPath,
                                 Subject subject,
                                 Course course,
                                 String time) {
        this.courseSubjectId = courseSubjectId;
        this.topicName = topicName;
        this.topicDescription = topicDescription;
        this.topicRemarks = topicRemarks;
        this.topicNotesPath = topicNotesPath;
        this.subject = subject;
        this.course = course;
        this.createdTime = time;
    }

    public String getTopicName() {
        return topicName;
    }

    public void setTopicName(String topicName) {
        this.topicName = topicName;
    }


    public String getCourseSubjectId() {
        return courseSubjectId;
    }

    public void setCourseSubjectId(String courseSubjectId) {
        this.courseSubjectId = courseSubjectId;
    }

    public String getCreatedTime() {
        return createdTime;
    }

    public void setCreatedTime(String createdTime) {
        this.createdTime = createdTime;
    }

    public String getTopicDescription() {
        return topicDescription;
    }

    public void setTopicDescription(String topicDescription) {
        this.topicDescription = topicDescription;
    }

    public String getTopicRemarks() {
        return topicRemarks;
    }

    public void setTopicRemarks(String topicRemarks) {
        this.topicRemarks = topicRemarks;
    }

    public String getTopicNotesPath() {
        return topicNotesPath;
    }

    public void setTopicNotesPath(String topicNotesPath) {
        this.topicNotesPath = topicNotesPath;
    }

    public Subject getSubject() {
        return subject;
    }

    public void setSubject(Subject subject) {
        this.subject = subject;
    }

    public Course getCourse() {
        return course;
    }

    public void setCourse(Course course) {
        this.course = course;
    }
}
