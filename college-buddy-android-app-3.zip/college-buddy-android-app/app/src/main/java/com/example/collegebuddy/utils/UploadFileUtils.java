package com.example.collegebuddy.utils;

import android.content.ContentResolver;
import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;
import android.util.Log;
import android.widget.Toast;

import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.Volley;
import com.example.collegebuddy.R;
import com.example.collegebuddy.callback.ServerCallbackJSONArray;
import com.example.collegebuddy.constants.ApplicationConstants;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class UploadFileUtils {

    public static byte[] getBytesFromInputStream(InputStream is) throws IOException {
        ByteArrayOutputStream os = new ByteArrayOutputStream();
        byte[] buffer = new byte[0xFFFF];
        for (int len = is.read(buffer); len != -1; len = is.read(buffer)) {
            os.write(buffer, 0, len);
        }
        return os.toByteArray();
    }

    public static void uploadFile(Uri uri, Context context, String uploadURL,  String fileName,
                                  ServerCallbackJSONArray serverCallbackJSONArray) throws IOException {

        byte[] arr = new byte[0];

        try  {
            InputStream fn = context.getContentResolver().openInputStream(uri);
            arr = getBytesFromInputStream(fn);
        } catch (IOException e) {
            // Error occurred when opening raw file for reading.
        }
        //Log.d("data", contents);
        Map<String, String> params = new HashMap<String, String>();
        SharedPreferences sharedPref = context.getSharedPreferences(ApplicationConstants.SHAREDPREF_FILE,
                context.MODE_PRIVATE);
        String token = sharedPref.getString(context.getString(R.string.auth_token), "");
        params.put("Authorization", token);

        byte[] finalArr = arr;
        MultipartRequest volleyMultipartRequest = new MultipartRequest(Request.Method.POST, uploadURL, params,
                new Response.Listener<NetworkResponse>() {
                    @Override
                    public void onResponse(NetworkResponse response) {
                        try {
                            JSONObject obj = new JSONObject(new String(response.data));
                            Toast.makeText(context, obj.getString("message"), Toast.LENGTH_SHORT).show();
                            if (obj.getString("response").equals("SUCCESS")){
                                List<String> mapList = new ArrayList<>();
                                mapList.add(obj.getString("file_path"));
                                serverCallbackJSONArray.onSuccess(mapList);
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.e("GotError",""+error.getMessage());
                    }
                }) {

            @Override
            protected Map<String, DataPart> getByteData() {
                Map<String, DataPart> params = new HashMap<>();
                params.put("file", new DataPart(fileName, finalArr));
                return params;
            }

        };

        //adding the request to volley
        Volley.newRequestQueue(context).add(volleyMultipartRequest);
    }

}
