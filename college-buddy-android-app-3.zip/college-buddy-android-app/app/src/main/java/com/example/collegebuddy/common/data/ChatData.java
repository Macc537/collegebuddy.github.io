package com.example.collegebuddy.common.data;

import android.content.Context;
import android.content.SharedPreferences;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.example.collegebuddy.R;
import com.example.collegebuddy.callback.ServerCallbackJSONArray;
import com.example.collegebuddy.common.entities.Chat;
import com.example.collegebuddy.constants.ApplicationConstants;
import com.example.collegebuddy.constants.URLConstants;
import com.example.collegebuddy.entities.Post;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ChatData {
    public Context context;
    private List<Chat> chatList;


    public ChatData(Context context) {
        this.context = context;
    }

    public void getChatsForUser(String userId, ServerCallbackJSONArray serverCallbackJSONArray){
        chatList = new ArrayList<>();
        RequestQueue queue = Volley.newRequestQueue(this.context);
        JSONObject postData = new JSONObject();

        try {
            postData.put("recipient", userId);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        String url = URLConstants.BASE_URL + ":" + URLConstants.CHAT_PORT +
                "/" + URLConstants.CHAT_ROUTE + "/"
                + URLConstants.CHAT_LIST;

        // Request a string response from the provided URL.
        JsonObjectRequest stringRequest = new JsonObjectRequest(Request.Method.POST, url, postData,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        // Display the first 500 characters of the response string.
                        System.out.println(response);
                        try {
                            JSONArray array = response.getJSONArray("messages");
                            for (int i = 0; i < array.length(); i++) {
                                JSONObject obj = array.getJSONObject(i);
                                Chat chat = new Chat();
                                chat.setSender(obj.getString("sender"));
                                chat.setTimestamp(obj.getString("sent_time"));
                                //chat.setMessage(obj.getString("message"));
                                chat.setMessage(" ");
                                chat.setReceiver(userId);
                                chatList.add(chat);
                            }
                            serverCallbackJSONArray.onSuccess(chatList);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        }
        ){
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();
                params.put("Content-Type", "application/json; charset=UTF-8");
                SharedPreferences sharedPref = context.getSharedPreferences(ApplicationConstants.SHAREDPREF_FILE,
                        context.MODE_PRIVATE);
                String token = sharedPref.getString(context.getString(R.string.auth_token), "");
                params.put("Authorization", token);
                return params;
            }
        };
        //Add the request to the RequestQueue.
        queue.add(stringRequest);

    }

    public void getChatsForSenderReceiver(String sender, String receiver, ServerCallbackJSONArray serverCallbackJSONArray){
        chatList = new ArrayList<>();
        RequestQueue queue = Volley.newRequestQueue(this.context);
        JSONObject postData = new JSONObject();

        try {
            postData.put("sender", sender);
            postData.put("recipient", receiver);

        } catch (JSONException e) {
            e.printStackTrace();
        }

        String url = URLConstants.BASE_URL + ":" + URLConstants.CHAT_PORT +
                "/" + URLConstants.CHAT_ROUTE + "/"
                + URLConstants.USER_CHAT_LIST;

        // Request a string response from the provided URL.
        JsonObjectRequest stringRequest = new JsonObjectRequest(Request.Method.POST, url, postData,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        // Display the first 500 characters of the response string.
                        System.out.println(response);
                        try {
                            JSONArray array = response.getJSONArray("messages");
                            for (int i = 0; i < array.length(); i++) {
                                JSONObject obj = array.getJSONObject(i);
                                Chat chat = new Chat();
                                chat.setSender(obj.getString("sender"));
                                chat.setTimestamp(obj.getString("sent_time"));
                                chat.setMessage(obj.getString("message"));
                                chat.setReceiver(obj.getString("recipient"));
                                chatList.add(chat);
                            }
                            serverCallbackJSONArray.onSuccess(chatList);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        }
        ){
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();
                params.put("Content-Type", "application/json; charset=UTF-8");
                SharedPreferences sharedPref = context.getSharedPreferences(ApplicationConstants.SHAREDPREF_FILE,
                        context.MODE_PRIVATE);
                String token = sharedPref.getString(context.getString(R.string.auth_token), "");
                params.put("Authorization", token);
                return params;
            }
        };
        //Add the request to the RequestQueue.
        queue.add(stringRequest);

    }

}
