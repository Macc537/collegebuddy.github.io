package com.example.collegebuddy.teacher;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.collegebuddy.R;
import com.example.collegebuddy.callback.ServerCallbackJSONArray;
import com.example.collegebuddy.data.AssignmentSubmissionsData;
import com.example.collegebuddy.entities.AssignmentSubmission;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.List;

public class CheckAssignmentActivity extends AppCompatActivity {
    String studentId;
    String assignmentId;

    Button btnUpdateMarks;
    TextView textViewAssignmentId;
    TextView textViewStudentId, textViewSolutionAns;
    EditText editTextMarks;
    AssignmentSubmissionsData assignmentSubmissionsData;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_check_assignment);
        Intent intent = getIntent();
//        AssignmentSubmission submission = (AssignmentSubmission) intent.getSerializableExtra("submissionObj");
        assignmentId = intent.getStringExtra("assignmentId");
        studentId = intent.getStringExtra("studentId");

        assignmentSubmissionsData = new AssignmentSubmissionsData(getApplicationContext());

        textViewStudentId = findViewById(R.id.textViewStudentId);
        textViewAssignmentId = findViewById(R.id.textViewAssignmentId);
        textViewSolutionAns = findViewById(R.id.textViewSolutionAns);
        editTextMarks = findViewById(R.id.editTextMarks);
        btnUpdateMarks = findViewById(R.id.buttonUpdateMarks);
        btnUpdateMarks.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                updateMarksInDB();
            }
        });


    }

    @Override
    protected void onResume() {
        super.onResume();
        JSONObject inputObj = new JSONObject();
        try {
            inputObj.put("student_id", studentId);
            inputObj.put("assignment_id", assignmentId);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        assignmentSubmissionsData.getStudentSubmission(inputObj, new ServerCallbackJSONArray() {
            @Override
            public void onSuccess(List result) {
                if (result.size() > 0){
                    AssignmentSubmission submission = (AssignmentSubmission) result.get(0);
                    textViewStudentId.setText(submission.getStudent().getUserId());
                    textViewAssignmentId.setText(submission.getAssignment().getAssignmentId());
                    textViewSolutionAns.setText(submission.getSubmittedFile());
                }

            }
        });

    }

    public void updateMarksInDB(){
        String marks = String.valueOf(editTextMarks.getText());
        JSONObject assignmentObj = new JSONObject();

        try {
            assignmentObj.put("assignment_id", assignmentId);
            assignmentObj.put("student_id", studentId);
            assignmentObj.put("marks", marks);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        assignmentSubmissionsData.updateAssignmentsSubmissions(assignmentObj, new ServerCallbackJSONArray() {
            @Override
            public void onSuccess(List result) {
                finish();
            }
        });

    }
}