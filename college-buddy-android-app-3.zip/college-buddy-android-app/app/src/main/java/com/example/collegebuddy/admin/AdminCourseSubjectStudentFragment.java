package com.example.collegebuddy.admin;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

import com.amazonaws.AmazonServiceException;
import com.amazonaws.auth.CognitoCachingCredentialsProvider;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3Client;
import com.amazonaws.services.s3.model.ObjectMetadata;
import com.amazonaws.services.s3.model.PutObjectRequest;


//import com.amplifyframework.AmplifyException;
//import com.amplifyframework.auth.cognito.AWSCognitoAuthPlugin;
//import com.amplifyframework.core.Amplify;
//import com.amplifyframework.storage.s3.AWSS3StoragePlugin;
import com.example.collegebuddy.R;
import com.example.collegebuddy.callback.ServerCallbackJSONArray;
import com.example.collegebuddy.constants.ApplicationConstants;
import com.example.collegebuddy.constants.URLConstants;
import com.example.collegebuddy.data.CoursesData;
import com.example.collegebuddy.data.CoursesSubjectMappedData;
import com.example.collegebuddy.data.SubjectsData;
import com.example.collegebuddy.data.UsersData;
import com.example.collegebuddy.entities.Course;
import com.example.collegebuddy.entities.CourseSubjectTeacher;
import com.example.collegebuddy.entities.Subject;
import com.example.collegebuddy.utils.UploadFileUtils;

import org.json.JSONArray;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class AdminCourseSubjectStudentFragment extends Fragment implements AdapterView.OnItemSelectedListener {


    Spinner spinnerSubject;
    private List<CourseSubjectTeacher> mappedSubjects = new ArrayList<>();
    private CoursesSubjectMappedData coursesSubjectMappedData;
    String selectedSubject;
    Uri fileRef;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view =  inflater.inflate(R.layout.fragment_admin_course_subject_student,
                container, false);

        coursesSubjectMappedData = new CoursesSubjectMappedData(getActivity());

        spinnerSubject = (Spinner) view.findViewById(R.id.spinner_subject_f2);
        spinnerSubject.setOnItemSelectedListener(this);

        Button selectFile = view.findViewById(R.id.upload_students_subjects_file);

        selectFile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.setType("*/*");
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                startActivityForResult(Intent.createChooser(intent,"Select file or dir"), 1);

            }
        });
        Button uploadButton = view.findViewById(R.id.save_students_subjects);
        uploadButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    String url = URLConstants.BASE_URL + ":" + URLConstants.COURSE_SUBJECT_PORT +
                            "/" + URLConstants.COURSE_SUBJECT_ROUTE + "/"
                            + URLConstants.UPLOAD_STUDENT_SUBJECTS_END_POINT;
                    String fileName = selectedSubject;
                    UploadFileUtils.uploadFile(fileRef, getActivity(), url, fileName, new ServerCallbackJSONArray() {
                        @Override
                        public void onSuccess(List result) {
                            Log.d("Message", String.valueOf(result.get(0)));

                        }
                    });

                } catch (Exception exc) {
                    Toast.makeText(getActivity(), exc.getMessage(), Toast.LENGTH_SHORT).show();
                    Log.e("ERROR", exc.getLocalizedMessage());
                    exc.printStackTrace();

                }

            }
        });

        return view;
    }

    @Override
    public void onResume() {
        super.onResume();
        coursesSubjectMappedData.getAllCoursesMapped(new ServerCallbackJSONArray() {
            @Override
            public void onSuccess(List result) {
                mappedSubjects = result;
                ArrayAdapter<CourseSubjectTeacher> dataAdapter = new ArrayAdapter<CourseSubjectTeacher>(getActivity(),
                        android.R.layout.simple_spinner_item,
                        mappedSubjects);
                dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                spinnerSubject.setAdapter(dataAdapter);
            }
        });
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        Log.e("Content","In on activity");
        if (requestCode == 1 && resultCode == Activity.RESULT_OK) {
            fileRef = data.getData();
        }
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        switch (parent.getId()){
            case R.id.spinner_subject_f2:
                selectedSubject = mappedSubjects.get(position).getCourseSubjectId();
                break;
        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {
    }
}