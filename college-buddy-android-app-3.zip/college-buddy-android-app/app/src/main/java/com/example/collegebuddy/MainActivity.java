package com.example.collegebuddy;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.DocumentsContract;
import android.provider.MediaStore;
import android.provider.OpenableColumns;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.example.collegebuddy.constants.ApplicationConstants;
import com.example.collegebuddy.constants.URLConstants;
import com.example.collegebuddy.utils.FilePath;
import com.example.collegebuddy.utils.MultipartRequest;

import net.gotev.uploadservice.MultipartUploadRequest;
import net.gotev.uploadservice.UploadNotificationConfig;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

public class MainActivity extends AppCompatActivity {

    private Button loginButton;
    private EditText userNameField;
    private EditText passwordField;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        SharedPreferences sharedPref = getSharedPreferences(ApplicationConstants.SHAREDPREF_FILE, MODE_PRIVATE);
        String userId = sharedPref.getString(getString(R.string.user_id), "");
        String token = sharedPref.getString(getString(R.string.auth_token), "");

        if (!userId.equals("") && !token.equals("")) {
            Intent i = new Intent(getApplicationContext(), LandingActivity.class);
            finish();
            startActivity(i);
        }

        loginButton = this.findViewById(R.id.buttonLogin);
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                MainActivity.this.login();
            }
        });

        userNameField = this.findViewById(R.id.editTextUserName);
        passwordField = this.findViewById(R.id.editTextPassword);

    }

    public void login() {
        System.out.println(userNameField.getText());
        // Instantiate the RequestQueue.
        RequestQueue queue = Volley.newRequestQueue(this);
        String url = URLConstants.BASE_URL + ":" + URLConstants.AUTH_PORT +
                "/" + URLConstants.AUTH_ROUTE + "/"
                + URLConstants.LOGIN_END_POINT;
        JSONObject postData = new JSONObject();
        System.out.println(url);
        try {
            postData.put("username", userNameField.getText());
            postData.put("password", passwordField.getText());

        } catch (JSONException e) {
            e.printStackTrace();
        }

        // Request a string response from the provided URL.
        JsonObjectRequest stringRequest = new JsonObjectRequest(Request.Method.POST, url, postData,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        // Display the first 500 characters of the response string.
                        System.out.println(response);
                        try {
                            String status_code = response.getString("response");
                            String message = response.getString("message");
                            if (status_code.equals(ApplicationConstants.RESPONSE_ERROR)) {
                                Toast.makeText(MainActivity.this, message, Toast.LENGTH_SHORT).show();
                            } else if (status_code.equals(ApplicationConstants.RESPONSE_SUCCESS)) {
                                Toast.makeText(MainActivity.this, message, Toast.LENGTH_SHORT).show();
                                JSONObject user = response.getJSONObject("user");
                                String token = response.getString("token");
                                String isFirstLogin = response.getString("is_password_reset");
                                SharedPreferences sharedPref = getSharedPreferences(ApplicationConstants.SHAREDPREF_FILE,
                                        MODE_PRIVATE);
                                SharedPreferences.Editor editor = sharedPref.edit();
                                editor.putString(getString(R.string.is_first_time), isFirstLogin);
                                editor.putString(getString(R.string.user_id), user.getString("user_id"));

                                if (isFirstLogin.equals(ApplicationConstants.NO)){
                                    editor.putString(getString(R.string.auth_token), token);
                                    JSONArray roles = response.getJSONArray("roles");
                                    Set<String> roleSet = new HashSet<>();
                                    for (int i = 0; i < roles.length(); i++) {
                                        roleSet.add(roles.getString(i));
                                    }
                                    editor.putStringSet(getString(R.string.user_roles), roleSet);
                                }
                                editor.apply();
                                Intent i = new Intent(getApplicationContext(), LandingActivity.class);
                                finish();
                                startActivity(i);
                            } else {
                                Toast.makeText(MainActivity.this, "Unknown Response", Toast.LENGTH_SHORT).show();
                            }

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        }
        );
        //Add the request to the RequestQueue.
        queue.add(stringRequest);
    }

}