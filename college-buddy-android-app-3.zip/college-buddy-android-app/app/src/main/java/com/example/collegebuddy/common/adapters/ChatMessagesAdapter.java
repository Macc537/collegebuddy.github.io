package com.example.collegebuddy.common.adapters;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.collegebuddy.R;
import com.example.collegebuddy.common.entities.Chat;
import com.example.collegebuddy.constants.ApplicationConstants;
import com.example.collegebuddy.data.AssignmentData;
import com.example.collegebuddy.teacher.UploadSubjectiveAssignmentQuestionsActivity;

import java.util.List;


public class ChatMessagesAdapter extends RecyclerView.Adapter<ChatMessagesAdapter.ViewHolder> {

    private List<Chat> chatList;
    private Context context;
    private AssignmentData assignmentData;

    public ChatMessagesAdapter(List<Chat> listData) {
        this.chatList = listData;
    }

    public ChatMessagesAdapter(List<Chat> chatList, Context context) {
        this.chatList = chatList;
        this.context = context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View listItem = layoutInflater.inflate(R.layout.chat_msg,
                parent, false);
        ChatMessagesAdapter.ViewHolder viewHolder = new ChatMessagesAdapter.ViewHolder(listItem);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, @SuppressLint("RecyclerView") int position) {
        final Chat chat = chatList.get(position);
        SharedPreferences sharedPref = context.getSharedPreferences(ApplicationConstants.SHAREDPREF_FILE,
                context.MODE_PRIVATE);
        String user_id = sharedPref.getString(context.getString(R.string.user_id), "");
        holder.textViewMsg.setText(chat.getMessage());

        if (user_id.equals(chat.getReceiver())){
            holder.textViewMsg.setGravity(Gravity.END);
        }
    }

    @Override
    public int getItemCount() {
        return chatList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public TextView textViewMsg;

        public ViewHolder(View itemView) {
            super(itemView);
            this.textViewMsg = (TextView) itemView.findViewById(R.id.textViewChatMessage);

        }
    }

}
