package com.example.collegebuddy.entities;

import java.util.List;

public class AssignmentQuestion {

    private String assignmentId;
    private String questionId;
    private String question_description;
    private String question_file_path;
    private String question_marks;
    private List<ObjectiveOption> options;
    private String selectedOption;
    private String correctOption;

    public String getAssignmentId() {
        return assignmentId;
    }

    public String getCorrectOption() {
        return correctOption;
    }

    public void setCorrectOption(String correctOption) {
        this.correctOption = correctOption;
    }

    public void setAssignmentId(String assignmentId) {
        this.assignmentId = assignmentId;
    }

    public String getQuestionId() {
        return questionId;
    }

    public String getSelectedOption() {
        return selectedOption;
    }

    public void setSelectedOption(String correctOption) {
        this.selectedOption = correctOption;
    }

    public void setQuestionId(String questionId) {
        this.questionId = questionId;
    }

    public String getQuestion_description() {
        return question_description;
    }

    public void setQuestion_description(String question_description) {
        this.question_description = question_description;
    }

    public String getQuestion_file_path() {
        return question_file_path;
    }

    public void setQuestion_file_path(String question_file_path) {
        this.question_file_path = question_file_path;
    }

    public String getQuestion_marks() {
        return question_marks;
    }

    public void setQuestion_marks(String question_marks) {
        this.question_marks = question_marks;
    }

    public List<ObjectiveOption> getOptions() {
        return options;
    }

    public void setOptions(List<ObjectiveOption> options) {
        this.options = options;
    }
}
