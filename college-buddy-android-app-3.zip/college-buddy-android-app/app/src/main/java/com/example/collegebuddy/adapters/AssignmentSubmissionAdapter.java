package com.example.collegebuddy.adapters;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.collegebuddy.R;
import com.example.collegebuddy.entities.AssignmentQuestion;
import com.example.collegebuddy.entities.AssignmentSubmission;
import com.example.collegebuddy.entities.User;
import com.example.collegebuddy.teacher.CheckAssignmentActivity;

import java.util.List;

public class AssignmentSubmissionAdapter extends RecyclerView.Adapter<AssignmentSubmissionAdapter.ViewHolder>  {


    private List<AssignmentSubmission> assignmentSubmissionList;
    private Context context;

    public AssignmentSubmissionAdapter(List<AssignmentSubmission> listData) {
        this.assignmentSubmissionList = listData;
    }

    public AssignmentSubmissionAdapter(List<AssignmentSubmission> assignmentSubmissionList,
                                       Context context) {
        this.assignmentSubmissionList = assignmentSubmissionList;
        this.context = context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View listItem = layoutInflater.inflate(R.layout.assignment_submission_card,
                parent, false);
        AssignmentSubmissionAdapter.ViewHolder viewHolder = new AssignmentSubmissionAdapter.ViewHolder(listItem);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        final AssignmentSubmission assignmentSubmission = assignmentSubmissionList.get(position);
        User student = assignmentSubmission.getStudent();
        String studentVal = student.getName() + "(" + student.getUserId() + ")";
        holder.textViewStudentId.setText(studentVal);
        holder.textViewSubmittedDate.setText(assignmentSubmission.getSubmittedTime());
        holder.textViewMarks.setText(assignmentSubmission.getMarks());

        if (assignmentSubmission.getMarks() == "null"){
            holder.textViewMarks.setVisibility(View.GONE);
        }else {
            holder.buttonCheckAssignment.setVisibility(View.GONE);
        }

        holder.buttonCheckAssignment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, CheckAssignmentActivity.class);
                intent.putExtra("studentId", assignmentSubmission.getStudent().getUserId());
                intent.putExtra("assignmentId", assignmentSubmission.getAssignment().getAssignmentId());
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(intent);
            }
        });

    }

    @Override
    public int getItemCount() {
        return assignmentSubmissionList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public TextView textViewStudentId;
        public TextView textViewSubmittedDate;
        public TextView textViewMarks;
        public Button buttonCheckAssignment;



        public ViewHolder(View itemView) {
            super(itemView);
            this.textViewStudentId = (TextView) itemView.findViewById(R.id.textViewStudentId);
            this.textViewSubmittedDate = (TextView) itemView.findViewById(R.id.textViewSubmittedDate);
            this.textViewMarks = (TextView) itemView.findViewById(R.id.textViewMarks);
            this.buttonCheckAssignment = (Button) itemView.findViewById(R.id.buttonCheckAssignment);
        }
    }

}
