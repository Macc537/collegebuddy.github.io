package com.example.collegebuddy.teacher;

import static android.content.Context.MODE_PRIVATE;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import com.example.collegebuddy.R;
import com.example.collegebuddy.adapters.CourseMaterialListAdapter;
import com.example.collegebuddy.callback.ServerCallbackJSONArray;
import com.example.collegebuddy.constants.ApplicationConstants;
import com.example.collegebuddy.data.SubjectTopicsData;
import com.example.collegebuddy.data.SubjectsData;
import com.example.collegebuddy.entities.Course;
import com.example.collegebuddy.entities.CourseSubjectMaterial;
import com.example.collegebuddy.entities.Subject;

import java.util.ArrayList;
import java.util.List;

public class TeacherSubjectFragment extends Fragment implements View.OnClickListener {
    String teacher_id;
    Button uploadNotes;
    RecyclerView recyclerView;
    private SubjectTopicsData subjectTopicsData ;
    List<CourseSubjectMaterial> courseSubjectMaterials = new ArrayList<>();

    public TeacherSubjectFragment() {
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view =  inflater.inflate(R.layout.fragment_teacher_subject,
                container, false);

        uploadNotes = view.findViewById(R.id.buttonAddCourseMaterial);
        uploadNotes.setOnClickListener(this);
        subjectTopicsData = new SubjectTopicsData(getContext());
        SharedPreferences sharedPref = getContext().getSharedPreferences(ApplicationConstants.SHAREDPREF_FILE, getContext().MODE_PRIVATE);
        teacher_id = sharedPref.getString(getString(R.string.user_id), "");
        recyclerView = (RecyclerView) view.findViewById(R.id.recyclerViewCourseSubjectMaterial);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        return view;
    }

    @Override
    public void onResume() {
        subjectTopicsData.getSubjectTopicsTeacher(teacher_id, new ServerCallbackJSONArray() {
            @Override
            public void onSuccess(List result) {
                courseSubjectMaterials = result;
                CourseMaterialListAdapter adapter = new CourseMaterialListAdapter(courseSubjectMaterials, getActivity());
                recyclerView.setAdapter(adapter);
            }
        });
        super.onResume();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.buttonAddCourseMaterial:
                System.out.println("start activity");
                Intent i = new Intent(getContext(), UploadCourseMaterialActivity.class);
                startActivity(i);
        }
    }
}