package com.example.collegebuddy.student;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.collegebuddy.R;
import com.example.collegebuddy.callback.ServerCallbackJSONArray;
import com.example.collegebuddy.constants.ApplicationConstants;
import com.example.collegebuddy.data.AssignmentData;
import com.example.collegebuddy.data.AssignmentQuestionsData;
import com.example.collegebuddy.data.AssignmentSubmissionsData;
import com.example.collegebuddy.entities.Assignment;
import com.example.collegebuddy.entities.AssignmentQuestion;
import com.example.collegebuddy.entities.AssignmentSubmission;
import com.example.collegebuddy.student.adapters.ObjectiveAssignmentQuestionListAdapter;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class ObjectiveAssignmentActivity extends AppCompatActivity implements View.OnClickListener {

    String student_id;
    Button submitAssignmentBtn;
    RecyclerView recyclerViewAssignmentQuestions;
    TextView textViewTotalMarks, textViewMarksReceived;
    TextView textViewAssignmentName;
    String assignment_id, assignmentName;
    List<AssignmentQuestion> assignmentQuestions;
    AssignmentQuestionsData assignmentQuestionsData;
    AssignmentData assignmentData;
    ObjectiveAssignmentQuestionListAdapter adapter;
    String isAssignmentSubmitted ;
    AssignmentSubmissionsData assignmentSubmissionsData;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_objective_assignment);

        SharedPreferences sharedPref =getSharedPreferences(ApplicationConstants.SHAREDPREF_FILE, MODE_PRIVATE);
        student_id = sharedPref.getString(getString(R.string.user_id), "");


        assignmentQuestions = new ArrayList<>();
        assignmentQuestionsData = new AssignmentQuestionsData(getApplicationContext());
        assignmentData = new AssignmentData(getApplicationContext());

        Intent intent = getIntent();
        assignment_id = intent.getStringExtra("assignment_id");
        assignmentName = intent.getStringExtra("assignmentName");
        isAssignmentSubmitted = intent.getStringExtra("is_assignment_submitted");


        String course_subject_id = intent.getStringExtra("course_subject_id");
        Toast.makeText(getApplicationContext(), assignment_id + "-" + course_subject_id, Toast.LENGTH_SHORT).show();

        textViewAssignmentName = findViewById(R.id.textviewassignmentName);
        textViewAssignmentName.setText(assignmentName);
        textViewTotalMarks= findViewById(R.id.textViewTotalMarks);
        textViewMarksReceived= findViewById(R.id.textViewMarksReceived);;

        submitAssignmentBtn = findViewById(R.id.buttonSubmitAssignmentQuestion);
        submitAssignmentBtn.setOnClickListener(this);

        if (isAssignmentSubmitted.equals("true")){
            submitAssignmentBtn.setVisibility(View.GONE);

            assignmentSubmissionsData = new AssignmentSubmissionsData(getApplicationContext());
            JSONObject inputObj = new JSONObject();
            try {
                inputObj.put("student_id", student_id);
                inputObj.put("assignment_id", assignment_id);
            } catch (JSONException e) {
                e.printStackTrace();
            }
            assignmentSubmissionsData.getStudentSubmission(inputObj, new ServerCallbackJSONArray() {
                @Override
                public void onSuccess(List result) {
                    AssignmentSubmission assignmentSubmission = (AssignmentSubmission) result.get(0);
                    textViewMarksReceived.setText(assignmentSubmission.getMarks()+"/");
                }
            });

        }else{
            textViewMarksReceived.setVisibility(View.GONE);
            textViewTotalMarks.setVisibility(View.GONE);
        }

        recyclerViewAssignmentQuestions = findViewById(R.id.recyclerViewAssignmentQuestions);

        assignmentQuestionsData.getObjectiveAssignmentsQuestions(assignment_id, new ServerCallbackJSONArray() {
            @Override
            public void onSuccess(List result) {
                assignmentQuestions = result;
                if (isAssignmentSubmitted.equals("true")){
                    adapter = new ObjectiveAssignmentQuestionListAdapter(assignmentQuestions,
                            getApplicationContext(),
                            true);
                }else {
                    adapter = new ObjectiveAssignmentQuestionListAdapter(assignmentQuestions,
                            getApplicationContext());
                }

                recyclerViewAssignmentQuestions.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
                recyclerViewAssignmentQuestions.setAdapter(adapter);
                Float marks = Float.valueOf(0);
                for (int i=0; i<assignmentQuestions.size(); i++){
                    AssignmentQuestion question = assignmentQuestions.get(i);
                    marks = marks + Float.valueOf(question.getQuestion_marks());
                }
                textViewTotalMarks.setText(String.valueOf(marks));
            }
        });


    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.buttonSubmitAssignmentQuestion:
                System.out.println("SAVE ASSIGNMENT ANSWER");
                JSONObject assignmentObj = new JSONObject();
                JSONArray questionArray = new JSONArray();
                for (int i = 0; i < assignmentQuestions.size(); i++){
                    AssignmentQuestion assignmentQuestion = assignmentQuestions.get(i);
                    JSONObject questionObj = new JSONObject();
                    try {
                        questionObj.put("question_id", assignmentQuestion.getQuestionId());
                        questionObj.put("selected_option", assignmentQuestion.getSelectedOption());
                        questionObj.put("marks", assignmentQuestion.getQuestion_marks());
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    questionArray.put(questionObj);
                }

                try {
                    assignmentObj.put("assignment_id", assignment_id);
                    assignmentObj.put("student_id", student_id);
                    assignmentObj.put("questions", questionArray);
                    assignmentObj.put("assignment_type", "objective");
                } catch (JSONException e) {
                    e.printStackTrace();
                }

                assignmentData.saveAssignmentsStudents(assignmentObj, new ServerCallbackJSONArray() {
                    @Override
                    public void onSuccess(List result) {
                        Toast.makeText(getApplicationContext(),
                                "Assignment Submitted",
                                Toast.LENGTH_SHORT).show();
                        finish();
                    }
                });

                break;
        }

    }
}