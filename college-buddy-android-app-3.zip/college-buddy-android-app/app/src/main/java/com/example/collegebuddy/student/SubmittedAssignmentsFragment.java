package com.example.collegebuddy.student;

import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.collegebuddy.R;
import com.example.collegebuddy.callback.ServerCallbackJSONArray;
import com.example.collegebuddy.constants.ApplicationConstants;
import com.example.collegebuddy.data.AssignmentData;
import com.example.collegebuddy.entities.Assignment;
import com.example.collegebuddy.student.adapters.AssignmentListAdapter;

import java.util.List;

public class SubmittedAssignmentsFragment extends Fragment {
    RecyclerView assignmentRecyclerView;
    AssignmentData assignmentData;
    List<Assignment> assignmentList;
    String student_id;

    public SubmittedAssignmentsFragment() {
        // Required empty public constructor
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view =  inflater.inflate(R.layout.fragment_submitted_assignments, container, false);

        assignmentData = new AssignmentData(getContext());
        SharedPreferences sharedPref = getContext().getSharedPreferences(ApplicationConstants.SHAREDPREF_FILE,
                getContext().MODE_PRIVATE);
        student_id = sharedPref.getString(getString(R.string.user_id), "");

        assignmentRecyclerView = (RecyclerView) view.findViewById(R.id.recyclerViewAssignment);
        assignmentRecyclerView.setHasFixedSize(true);
        assignmentRecyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        return view;
    }

    @Override
    public void onResume() {
        super.onResume();
        assignmentData.getSubmittedAssignmentsStudents(student_id, new ServerCallbackJSONArray() {
            @Override
            public void onSuccess(List result) {
                assignmentList = result;
                AssignmentListAdapter adapter = new AssignmentListAdapter(assignmentList,
                        getContext(), true);
                assignmentRecyclerView.setAdapter(adapter);
            }
        });
    }
}