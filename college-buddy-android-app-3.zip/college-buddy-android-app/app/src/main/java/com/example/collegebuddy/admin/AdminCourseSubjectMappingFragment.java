package com.example.collegebuddy.admin;

import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.collegebuddy.R;
import com.example.collegebuddy.callback.ServerCallbackJSONArray;
import com.example.collegebuddy.constants.ApplicationConstants;
import com.example.collegebuddy.constants.URLConstants;
import com.example.collegebuddy.data.CoursesData;
import com.example.collegebuddy.data.SubjectsData;
import com.example.collegebuddy.data.UsersData;
import com.example.collegebuddy.entities.Course;
import com.example.collegebuddy.entities.Subject;
import com.example.collegebuddy.entities.Teacher;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class AdminCourseSubjectMappingFragment extends Fragment implements View.OnClickListener {

    private Button addCourseSubjectButton;
    private Button saveCourseSubjectButton;
    private LinearLayout dynamicContent;

    private List<Course> courses = new ArrayList<>();
    private List<Subject> subjects = new ArrayList<>();
    private List<Teacher> teachers = new ArrayList<>();
    private List<Integer> semesters = Arrays.asList(ApplicationConstants.SEMESTER);

    private UsersData usersData;
    private SubjectsData subjectData;
    private CoursesData coursesData;


    List<Map<String, String>> subjectCourseMappingDetails = new ArrayList<>();

    public AdminCourseSubjectMappingFragment() {
        // Required empty public constructor
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view =  inflater.inflate(R.layout.fragment_admin_course_subject_mapping, container, false);
        usersData = new UsersData(getActivity().getApplicationContext());
        subjectData = new SubjectsData(getActivity().getApplicationContext());
        coursesData = new CoursesData(getActivity().getApplicationContext());

        dynamicContent = (LinearLayout) view.findViewById(R.id.dynamic_content_course_subject);
        addCourseSubjectButton = view.findViewById(R.id.add_course_subject_mapping);
        addCourseSubjectButton.setOnClickListener(this);
        saveCourseSubjectButton = view.findViewById(R.id.save_course_subject_details);
        saveCourseSubjectButton.setOnClickListener(this);
        saveCourseSubjectButton.setEnabled(false);

        subjectData.loadSubjects(new ServerCallbackJSONArray() {
            @Override
            public void onSuccess(List result) {
                subjects = result;
            }
        });

        usersData.loadTeachers(new ServerCallbackJSONArray(){
            @Override
            public void onSuccess(List result) {
                teachers = result;
            }
        });

        coursesData.loadCourses(new ServerCallbackJSONArray() {
            @Override
            public void onSuccess(List result) {
                courses = result;
            }
        });

        return view;

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.add_course_subject_mapping:
                createLayoutForCourseSubjectAdd();
                break;
            case R.id.save_course_subject_details:
                postCourseSubjectDetails();
                break;
        }

    }

    public void postCourseSubjectDetails(){

        RequestQueue queue = Volley.newRequestQueue(getContext());
        String url = URLConstants.BASE_URL + ":" + URLConstants.COURSE_SUBJECT_PORT +
                "/" + URLConstants.COURSE_SUBJECT_ROUTE + "/"
                + URLConstants.ADD_COURSE_SUBJECT_MAPPING_END_POINT;

        JSONArray array = new JSONArray();

        for(Map<String, String> data : subjectCourseMappingDetails) {
            JSONObject obj = new JSONObject(data);
            array.put(obj);
        }

        JSONObject obj = new JSONObject();
        try {
            obj.put("payload", array);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        // Request a string response from the provided URL.
        JsonObjectRequest stringRequest = new JsonObjectRequest(Request.Method.POST, url, obj,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        // Display the first 500 characters of the response string.
                        System.out.println(response);
                        try {
                            String message = response.getString("message");
                            Toast.makeText(getActivity(), message, Toast.LENGTH_SHORT).show();
                            dynamicContent.removeAllViewsInLayout();
                            subjectCourseMappingDetails = new ArrayList<>();
                            saveCourseSubjectButton.setEnabled(false);
                        } catch (Exception e) {
                            Toast.makeText(getActivity(), e.getMessage(), Toast.LENGTH_SHORT).show();
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getActivity(), error.getMessage(), Toast.LENGTH_SHORT).show();
                error.printStackTrace();
            }
        }
        ){
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();
                params.put("Content-Type", "application/json; charset=UTF-8");
                SharedPreferences sharedPref = getActivity().getSharedPreferences(ApplicationConstants.SHAREDPREF_FILE,
                        getActivity().MODE_PRIVATE);
                String token = sharedPref.getString(getString(R.string.auth_token), "");
                params.put("Authorization", token);
                return params;
            }
        };
        //Add the request to the RequestQueue.
        queue.add(stringRequest);


    }

    public void createLayoutForCourseSubjectAdd(){
        // assuming your Wizard content is in content_wizard.xml
        View wizardView = getLayoutInflater()
                .inflate(R.layout.add_course_subject_mapping_row, dynamicContent, false);

        // add the inflated View to the layout
        dynamicContent.addView(wizardView);

        Spinner spinnerCourse = (Spinner) wizardView.findViewById(R.id.spinner_course);
        ArrayAdapter<Course> dataAdapter = new ArrayAdapter<Course>(getActivity(),
                android.R.layout.simple_spinner_item,
                courses);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerCourse.setAdapter(dataAdapter);
//        spinnerCourse.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){
//            @Override
//            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
//                Course course = (Course) parent.getSelectedItem();
//                selectedCourse = course.getCourseId();
//            }
//            @Override
//            public void onNothingSelected(AdapterView<?> parent) {
//            }
//        });


        Spinner spinnerSubject = (Spinner) wizardView.findViewById(R.id.spinner_subject);
        ArrayAdapter<Subject> subjectDataAdapter = new ArrayAdapter<Subject>(getActivity(),
                android.R.layout.simple_spinner_item,
                subjects);
        subjectDataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerSubject.setAdapter(subjectDataAdapter);
//        spinnerSubject.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){
//            @Override
//            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
//                Subject subject = (Subject) parent.getSelectedItem();
//                selectedSubject = subject.getSubjectId();
//            }
//            @Override
//            public void onNothingSelected(AdapterView<?> parent) {
//            }
//        });

        Spinner spinnerTeacher = (Spinner) wizardView.findViewById(R.id.spinner_teacher);
        ArrayAdapter<Teacher> teacherDataAdapter = new ArrayAdapter<Teacher>(getActivity(),
                android.R.layout.simple_spinner_item,
                teachers);
        teacherDataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerTeacher.setAdapter(teacherDataAdapter);

        Spinner spinnerSemester = (Spinner) wizardView.findViewById(R.id.spinner_semester);
        ArrayAdapter<Integer> semesterDataAdapter = new ArrayAdapter<Integer>(getActivity(),
                android.R.layout.simple_spinner_item,
                semesters);
        semesterDataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerSemester.setAdapter(semesterDataAdapter);


    //        spinnerTeacher.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){
//            @Override
//            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
//                Teacher teacher = (Teacher) parent.getSelectedItem();
//                selectedTeacher = teacher.getTeacherId();
//            }
//            @Override
//            public void onNothingSelected(AdapterView<?> parent) {
//            }
//        });


        Button addDetails = wizardView.findViewById(R.id.add_course_subject_mapping_to_list);
        addDetails.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                int courseIndex = spinnerCourse.getSelectedItemPosition();
                int subjectIndex = spinnerSubject.getSelectedItemPosition();
                int teacherIndex = spinnerTeacher.getSelectedItemPosition();
                int semesterIndex = spinnerSemester.getSelectedItemPosition();

                Map<String, String> courseSubjectMap = new HashMap<>();
                courseSubjectMap.put("subject_id", subjects.get(subjectIndex).getSubjectId());
                courseSubjectMap.put("course_id", courses.get(courseIndex).getCourseId());
                    courseSubjectMap.put("teacher_id", teachers.get(teacherIndex).getTeacherId());
                courseSubjectMap.put("session_year", ApplicationConstants.SESSION_YEAR);


                courseSubjectMap.put("semester", String.valueOf(semesters.get(semesterIndex)));
                String id = courses.get(courseIndex).getCourseId() + "-" +
                        subjects.get(subjectIndex).getSubjectId() + "-" +
                        ApplicationConstants.SESSION_YEAR + "-S" +
                        String.valueOf(semesters.get(semesterIndex));

                courseSubjectMap.put("course_subject_id", id);

                if (addDetails.getText().toString().equals("Add")){
                    subjectCourseMappingDetails.add(courseSubjectMap);
                    //dynamicContent.removeView(wizardView);
                    spinnerCourse.setEnabled(false);
                    spinnerSubject.setEnabled(false);
                    spinnerTeacher.setEnabled(false);
                    spinnerSemester.setEnabled(false);
                    addDetails.setText("Delete");
                }else if (addDetails.getText().toString().equals("Delete")) {
                    subjectCourseMappingDetails.remove(courseSubjectMap);
                    dynamicContent.removeView(wizardView);
                }
                if (subjectCourseMappingDetails.size() > 0){
                    saveCourseSubjectButton.setEnabled(true);
                }else {
                    saveCourseSubjectButton.setEnabled(false);
                }
            }
        });
    }
}