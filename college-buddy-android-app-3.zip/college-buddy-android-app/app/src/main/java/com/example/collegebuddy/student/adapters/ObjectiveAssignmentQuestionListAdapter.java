package com.example.collegebuddy.student.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.collegebuddy.R;
import com.example.collegebuddy.adapters.ObjectiveQuestionOptionShowAdapter;
import com.example.collegebuddy.entities.AssignmentQuestion;

import org.w3c.dom.Text;

import java.util.List;

public class ObjectiveAssignmentQuestionListAdapter extends RecyclerView.Adapter<ObjectiveAssignmentQuestionListAdapter.ViewHolder>{

    private List<AssignmentQuestion> assignmentQuestionsList;
    private Context context;
    private Boolean isAssignmentSubmitted;

    public ObjectiveAssignmentQuestionListAdapter(List<AssignmentQuestion> listData) {
        this.assignmentQuestionsList = listData;
    }

    public ObjectiveAssignmentQuestionListAdapter(List<AssignmentQuestion> assignmentQuestionsList,
                                                  Context context) {
        this.assignmentQuestionsList = assignmentQuestionsList;
        this.context = context;
        this.isAssignmentSubmitted  = false;
    }


    public ObjectiveAssignmentQuestionListAdapter(List<AssignmentQuestion> assignmentQuestionsList,
                                                  Context context, Boolean isAssignmentSubmitted) {
        this.assignmentQuestionsList = assignmentQuestionsList;
        this.context = context;
        this.isAssignmentSubmitted = isAssignmentSubmitted;
    }


    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View listItem = layoutInflater.inflate(R.layout.student_objective_question_card,
                parent, false);
        ViewHolder viewHolder = new ViewHolder(listItem);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        final AssignmentQuestion assignmentQuestion = assignmentQuestionsList.get(position);
        holder.textViewQuestionId.setText(assignmentQuestion.getQuestionId());
        holder.textViewQuestionDesc.setText(assignmentQuestion.getQuestion_description());
        holder.textViewQuestionMarks.setText(assignmentQuestion.getQuestion_marks());

        ObjectiveQuestionOptionShowAdapter objectiveQuestionOptionShowAdapter = new ObjectiveQuestionOptionShowAdapter(assignmentQuestion.getOptions());
        holder.recyclerViewAssignmentOptions.setHasFixedSize(true);
        holder.recyclerViewAssignmentOptions.setLayoutManager(new LinearLayoutManager(context));
        holder.recyclerViewAssignmentOptions.setAdapter(objectiveQuestionOptionShowAdapter);

        holder.saveOptionAns.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                assignmentQuestion.setSelectedOption(String.valueOf(holder.editTextCorrectOption.getText()));
                holder.editTextCorrectOption.setEnabled(false);
            }
        });

        holder.unSaveOptionAns.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                holder.editTextCorrectOption.setEnabled(true);
            }
        });

        holder.correctOption.setText("Correct Option - " + assignmentQuestion.getCorrectOption());
        holder.selectedOption.setVisibility(View.GONE);
        //holder.selectedOption.setText("Selected Option - " + assignmentQuestion.getSelectedOption());

        if (this.isAssignmentSubmitted){
            holder.saveOptionAns.setVisibility(View.GONE);
            holder.unSaveOptionAns.setVisibility(View.GONE);
            holder.editTextCorrectOption.setVisibility(View.GONE);
        }else{
            holder.selectedOption.setVisibility(View.GONE);
            holder.correctOption.setVisibility(View.GONE);
        }
    }

    @Override
    public int getItemCount() {
        return assignmentQuestionsList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public TextView textViewQuestionId;
        public TextView textViewQuestionDesc;
        public TextView textViewQuestionMarks;
        public RecyclerView recyclerViewAssignmentOptions;
        public EditText editTextCorrectOption;
        public Button saveOptionAns;
        public Button unSaveOptionAns;

        public TextView selectedOption;
        public TextView correctOption;


        public ViewHolder(View itemView) {
            super(itemView);
            this.textViewQuestionId = (TextView) itemView.findViewById(R.id.textViewQuestionId);
            this.textViewQuestionDesc = (TextView) itemView.findViewById(R.id.textViewQuestionDescription);
            this.textViewQuestionMarks = (TextView) itemView.findViewById(R.id.textViewQuestionMarks);
            this.recyclerViewAssignmentOptions = (RecyclerView) itemView.findViewById(R.id.recyclerViewAssignmentOptions);
            this.editTextCorrectOption = (EditText) itemView.findViewById(R.id.editTextAns);
            this.saveOptionAns = (Button) itemView.findViewById(R.id.saveOptionAns);
            this.unSaveOptionAns = (Button) itemView.findViewById(R.id.unSaveOptionAns);


            this.selectedOption = (TextView) itemView.findViewById(R.id.textViewSelectedOption);
            this.correctOption = (TextView) itemView.findViewById(R.id.textViewTextAns);

        }
    }

}
