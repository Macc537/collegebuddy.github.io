package com.example.collegebuddy.teacher;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.collegebuddy.R;
import com.example.collegebuddy.callback.ServerCallbackJSONArray;
import com.example.collegebuddy.constants.ApplicationConstants;
import com.example.collegebuddy.constants.URLConstants;
import com.example.collegebuddy.data.CoursesData;
import com.example.collegebuddy.data.CoursesSubjectMappedData;
import com.example.collegebuddy.data.SubjectsData;
import com.example.collegebuddy.entities.Course;
import com.example.collegebuddy.entities.CourseSubjectMaterial;
import com.example.collegebuddy.entities.CourseSubjectTeacher;
import com.example.collegebuddy.entities.Subject;
import com.example.collegebuddy.utils.UploadFileUtils;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class UploadCourseMaterialActivity extends AppCompatActivity implements View.OnClickListener, AdapterView.OnItemSelectedListener {

    Button selectFile;
    Button saveNotes;
    Spinner subjectSpinner;
    String teacher_id, notesPath, topicId;
    String course_subject_id = "";
    EditText topicName, topicDesc, topicRemarks;

    private CoursesSubjectMappedData coursesSubjectMappedData;
    private List<CourseSubjectTeacher> mappedSubjects = new ArrayList<>();


    private static final int PICK_FILE_REQUEST = 9544;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_upload_course_material);

        SharedPreferences sharedPref = getSharedPreferences(ApplicationConstants.SHAREDPREF_FILE, MODE_PRIVATE);
        teacher_id = sharedPref.getString(getString(R.string.user_id), "");

        coursesSubjectMappedData = new CoursesSubjectMappedData(getApplicationContext());

        subjectSpinner = findViewById(R.id.spinner_subject_add_notes);
        subjectSpinner.setOnItemSelectedListener(this);

        selectFile = findViewById(R.id.buttonSelectFile);
        saveNotes = findViewById(R.id.buttonAddCourseMaterial);
        selectFile.setOnClickListener(this);
        saveNotes.setOnClickListener(this);

        topicName = findViewById(R.id.editTextTopicName);
        topicDesc = findViewById(R.id.editTextTopicDesc);
        topicRemarks = findViewById(R.id.editTextTopicRemarks);

        coursesSubjectMappedData.getTeacherSubjects(teacher_id, new ServerCallbackJSONArray() {
            @Override
            public void onSuccess(List result) {
                mappedSubjects = result;
                ArrayAdapter<CourseSubjectTeacher> dataAdapter = new ArrayAdapter<CourseSubjectTeacher>(getApplicationContext(),
                        android.R.layout.simple_spinner_item,
                        mappedSubjects);
                dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                subjectSpinner.setAdapter(dataAdapter);
            }
        });


    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.buttonSelectFile:
                System.out.println("Select File");
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.setType("application/pdf");
                startActivityForResult(Intent.createChooser(intent, "Select File"), PICK_FILE_REQUEST);
                break;
            case R.id.buttonAddCourseMaterial:
                System.out.println("Button Add");
                saveNotedInfoDB();
                break;
        }

    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        switch (parent.getId()){
            case R.id.spinner_subject_add_notes:
                System.out.println("subject selected");
                course_subject_id = mappedSubjects.get(position).getCourseSubjectId();
                topicId = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new Date());

        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_FILE_REQUEST) {
            if (resultCode == RESULT_OK) {
                Uri uri = data.getData();
                try {
                    String url = URLConstants.BASE_URL + ":" + URLConstants.COURSE_SUBJECT_PORT +
                            "/" + URLConstants.COURSE_SUBJECT_ROUTE + "/"
                            + URLConstants.UPLOAD_SUBJECTS_NOTES_END_POINT;
                    String fileName = course_subject_id + "|" + topicId;
                    UploadFileUtils.uploadFile(uri, getApplicationContext(), url, fileName, new ServerCallbackJSONArray() {
                        @Override
                        public void onSuccess(List result) {
                            notesPath = (String) result.get(0);
                        }
                    });

                } catch (Exception exc) {
                    Toast.makeText(this, exc.getMessage(), Toast.LENGTH_SHORT).show();
                    Log.e("ERROR", exc.getLocalizedMessage());
                    exc.printStackTrace();

                }
            }
        }
    }

    public void saveNotedInfoDB(){
        JSONObject object = new JSONObject();
        try {
            object.put("course_subject_id", course_subject_id);
            object.put("topic_id", topicId);
            object.put("topic_name", topicName.getText());
            object.put("topic_description", topicDesc.getText());
            object.put("topic_remarks", topicRemarks.getText());
            object.put("topic_notes_path", notesPath);

        } catch (JSONException e) {
            e.printStackTrace();
        }

        coursesSubjectMappedData.addCourseMaterial(object, new ServerCallbackJSONArray() {
            @Override
            public void onSuccess(List result) {
                finish();
            }
        });
    }
}