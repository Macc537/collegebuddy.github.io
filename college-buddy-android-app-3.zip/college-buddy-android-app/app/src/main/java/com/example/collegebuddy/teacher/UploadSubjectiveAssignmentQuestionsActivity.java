package com.example.collegebuddy.teacher;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.example.collegebuddy.R;
import com.example.collegebuddy.adapters.AssignmentListAdapter;
import com.example.collegebuddy.adapters.AssignmentQuestionsListAdapter;
import com.example.collegebuddy.callback.ServerCallbackJSONArray;
import com.example.collegebuddy.constants.ApplicationConstants;
import com.example.collegebuddy.constants.URLConstants;
import com.example.collegebuddy.data.AssignmentQuestionsData;
import com.example.collegebuddy.entities.AssignmentQuestion;
import com.example.collegebuddy.entities.CourseSubjectTeacher;
import com.example.collegebuddy.utils.UploadFileUtils;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class UploadSubjectiveAssignmentQuestionsActivity extends AppCompatActivity implements View.OnClickListener {

    private static final int PICK_FILE_REQUEST = 20012;
    Button addQuestionBtn;
    RecyclerView recyclerViewAssignmentQuestions;
    TextView textViewAssignmentName;
    String assignment_id, assignmentName, questionFilePath, course_subject_id;
    List<AssignmentQuestion> assignmentQuestions;
    AssignmentQuestionsData assignmentQuestionsData;
    AssignmentQuestionsListAdapter adapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_upload_assignment_questions);
        assignmentQuestions = new ArrayList<>();
        assignmentQuestionsData = new AssignmentQuestionsData(getApplicationContext());

        Intent intent = getIntent();
        assignment_id = intent.getStringExtra("assignment_id");
        assignmentName = intent.getStringExtra("assignmentName");

        course_subject_id = intent.getStringExtra("course_subject_id");
        Toast.makeText(getApplicationContext(), assignment_id + "-" + course_subject_id, Toast.LENGTH_SHORT).show();

        textViewAssignmentName = findViewById(R.id.textviewassignmentName);
        textViewAssignmentName.setText(assignmentName);
        addQuestionBtn = findViewById(R.id.buttonAddAssignmentQuestion);
        addQuestionBtn.setOnClickListener(this);
        recyclerViewAssignmentQuestions = findViewById(R.id.recyclerViewAssignmentQuestions);

        assignmentQuestionsData.getAssignmentsQuestions(assignment_id, new ServerCallbackJSONArray() {
            @Override
            public void onSuccess(List result) {
                assignmentQuestions = result;

                adapter = new AssignmentQuestionsListAdapter(assignmentQuestions, getApplicationContext());
                recyclerViewAssignmentQuestions.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
                recyclerViewAssignmentQuestions.setAdapter(adapter);
            }
        });

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.buttonAddAssignmentQuestion:
                AlertDialog.Builder builder = new AlertDialog.Builder(this);
                builder.setTitle("Add Question");
                LayoutInflater layoutInflater = getLayoutInflater();
                final View inflator = layoutInflater.inflate(R.layout.subjective_question_dialog, null);

                final EditText questionDescEditText = (EditText) inflator.findViewById(R.id.subjective_question_description);
                final EditText questionMarksEditText = (EditText) inflator.findViewById(R.id.subjective_question_marks);
                final Button buttonSelectAssignmentFile = (Button) inflator.findViewById(R.id.buttonSelectAssignmentFile);
                buttonSelectAssignmentFile.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        System.out.println("Select File");
                        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                        intent.setType("application/pdf");
                        startActivityForResult(Intent.createChooser(intent, "Select Assignment File"), PICK_FILE_REQUEST);
                    }
                });

                builder.setView(inflator)
                        .setPositiveButton(R.string.add_question, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                String ques = String.valueOf(questionDescEditText.getText());
                                String quesMarks = String.valueOf(questionMarksEditText.getText());
                                Toast.makeText(getApplicationContext(), ques + quesMarks, Toast.LENGTH_SHORT).show();
                                Map<String, String> data = new HashMap<>();
                                data.put("question_description",ques);
                                data.put("question_marks", quesMarks);
                                data.put("question_file_path", questionFilePath);
                                data.put("assignment_id", assignment_id);
                                data.put("question_id", String.valueOf(assignmentQuestions.size() + 1));
                                saveQuestionInDB(data);
                            }
                        })
                        .setNegativeButton(R.string.cancel, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                            }
                        });
                builder.show();
                break;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_FILE_REQUEST) {
            if (resultCode == RESULT_OK) {
                Uri uri = data.getData();
                try {
                    String url = URLConstants.BASE_URL + ":" + URLConstants.ASSIGNMENT_PORT +
                            "/" + URLConstants.ASSIGNMENT_ROUTE + "/"
                            + URLConstants.UPLOAD_SUBJECTIVE_ASSIGNMENT;
                    String fileName =  course_subject_id +  "|" + assignment_id + "-Q" + String.valueOf(assignmentQuestions.size() + 1);
                    UploadFileUtils.uploadFile(uri, getApplicationContext(), url, fileName, new ServerCallbackJSONArray() {
                        @Override
                        public void onSuccess(List result) {
                            Log.d("Message", String.valueOf(result.get(0)));
                            questionFilePath =  String.valueOf(result.get(0));
                        }
                    });
                } catch (Exception exc) {
                    Toast.makeText(this, exc.getMessage(), Toast.LENGTH_SHORT).show();
                    Log.e("ERROR", exc.getLocalizedMessage());
                    exc.printStackTrace();

                }
            }
        }
    }

    public void saveQuestionInDB(Map<String, String> data){
        RequestQueue queue = Volley.newRequestQueue(getApplicationContext());
        String url = URLConstants.BASE_URL + ":" + URLConstants.ASSIGNMENT_PORT +
                "/" + URLConstants.ASSIGNMENT_ROUTE + "/"
                + URLConstants.ADD_ASSIGNMENT_QUESTION_END_POINT;

        Toast.makeText(getApplicationContext(), url, Toast.LENGTH_SHORT).show();
        JSONArray array = new JSONArray();
        array.put(new JSONObject(data));
        JSONObject obj = new JSONObject();
        try {
            obj.put("payload", array);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        // Request a string response from the provided URL.
        JsonObjectRequest stringRequest = new JsonObjectRequest(Request.Method.POST, url, obj,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        // Display the first 500 characters of the response string.
                        System.out.println(response);
                        try {
                            System.out.println(response.get("response"));
                            System.out.println(response.get("message"));
                            AssignmentQuestion assignmentQuestion = new AssignmentQuestion();
                            assignmentQuestion.setQuestionId(String.valueOf(assignmentQuestions.size() + 1));
                            assignmentQuestion.setQuestion_marks(data.get("question_marks"));
                            assignmentQuestion.setQuestion_description(data.get("question_description"));
                            assignmentQuestion.setAssignmentId(assignment_id);
                            assignmentQuestion.setQuestion_file_path(data.get("question_file_path"));
                            //adapter.addItem(0, assignmentQuestion);
                            assignmentQuestions.add(0, assignmentQuestion);
                            adapter.notifyItemInserted(0);
                            //assignmentQuestions.add(assignmentQuestion);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        }
        ){
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();
                params.put("Content-Type", "application/json; charset=UTF-8");
                SharedPreferences sharedPref = getSharedPreferences(ApplicationConstants.SHAREDPREF_FILE,
                        MODE_PRIVATE);
                String token = sharedPref.getString(getString(R.string.auth_token), "");
                params.put("Authorization", token);
                return params;
            }
        };
        //Add the request to the RequestQueue.
        queue.add(stringRequest);

    }
}