package com.example.collegebuddy.adapters;

import android.content.Context;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageButton;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.collegebuddy.R;
import com.example.collegebuddy.callback.ServerCallbackJSONArray;
import com.example.collegebuddy.constants.ApplicationConstants;
import com.example.collegebuddy.entities.Assignment;
import com.example.collegebuddy.entities.ObjectiveOption;
import com.example.collegebuddy.entities.Post;

import java.util.List;

public class ObjectiveQuestionOptionAdapter extends RecyclerView.Adapter<ObjectiveQuestionOptionAdapter.ViewHolder>  {

    private List<ObjectiveOption> objectiveOptionList;
    private Context context;

    public ObjectiveQuestionOptionAdapter(List<ObjectiveOption> listData) {
        this.objectiveOptionList = listData;
    }

    public ObjectiveQuestionOptionAdapter(List<ObjectiveOption> listData, Context context) {
        this.objectiveOptionList = listData;
        this.context = context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View listItem = layoutInflater.inflate(R.layout.objective_question_option,
                parent, false);
        ObjectiveQuestionOptionAdapter.ViewHolder viewHolder = new ObjectiveQuestionOptionAdapter.ViewHolder(listItem);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        final ObjectiveOption objectiveOption = objectiveOptionList.get(position);
//        holder.imageButtonSave.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                String optionVal = String.valueOf(holder.editTextOption.getText());
//                objectiveOption.setOptionValue(optionVal);
//                //                postData.updatePostStatus(post.getPost_id(),
////                        ApplicationConstants.POST_CLOSE_STATUS, new ServerCallbackJSONArray() {
////                            @Override
////                            public void onSuccess(List result) {
////                                postList.remove(post);
////                                notifyItemRemoved(position);
////                            }
////                        });
//            }
//        });
        holder.editTextOption.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                String optionVal = String.valueOf(holder.editTextOption.getText());
                objectiveOption.setOptionValue(optionVal);
            }
        });
    }

    @Override
    public int getItemCount() {
        return objectiveOptionList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public EditText editTextOption;
        //public ImageButton imageButtonSave;

        public ViewHolder(View itemView) {
            super(itemView);
            this.editTextOption = (EditText) itemView.findViewById(R.id.editTextOption);
            //this.imageButtonSave = (ImageButton) itemView.findViewById(R.id.imageButtonSave);
        }
    }

}
