package com.example.collegebuddy.data;

import android.content.Context;
import android.content.SharedPreferences;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.example.collegebuddy.R;
import com.example.collegebuddy.callback.ServerCallbackJSONArray;
import com.example.collegebuddy.constants.ApplicationConstants;
import com.example.collegebuddy.constants.URLConstants;
import com.example.collegebuddy.entities.Post;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class PostData {
    public Context context;
    private List<Post> postList;


    public PostData(Context context) {
        this.context = context;
    }


    public void getPostsForAdmin( ServerCallbackJSONArray serverCallbackJSONArray){
        postList = new ArrayList<>();
        RequestQueue queue = Volley.newRequestQueue(this.context);
        JSONObject postData = new JSONObject();

        String url = URLConstants.BASE_URL + ":" + URLConstants.POST_PORT +
                "/" + URLConstants.POST_ROUTE + "/"
                + URLConstants.GET_POST_FOR_ADMIN_END_POINT;

        // Request a string response from the provided URL.
        JsonObjectRequest stringRequest = new JsonObjectRequest(Request.Method.POST, url, postData,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        // Display the first 500 characters of the response string.
                        System.out.println(response);
                        try {
                            String msg = response.getString("message");
                            JSONArray array = response.getJSONArray("posts");
                            for (int i = 0; i < array.length(); i++) {
                                JSONObject obj = array.getJSONObject(i);
                                Post post = new Post();
                                post.setPost_id(obj.getString("post_id"));
                                post.setPost_desc(obj.getString("post_desc"));
                                post.setPost_heading(obj.getString("post_heading"));
                                post.setPosted_by(obj.getString("posted_by"));
                                post.setDue_date(obj.getString("due_date"));
                                post.setCreated_at(obj.getString("created_at"));
                                post.setStatus(obj.getString("status"));
                                postList.add(post);
                            }
                            serverCallbackJSONArray.onSuccess(postList);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        }
        ){
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();
                params.put("Content-Type", "application/json; charset=UTF-8");
                SharedPreferences sharedPref = context.getSharedPreferences(ApplicationConstants.SHAREDPREF_FILE,
                        context.MODE_PRIVATE);
                String token = sharedPref.getString(context.getString(R.string.auth_token), "");
                params.put("Authorization", token);
                return params;
            }
        };
        //Add the request to the RequestQueue.
        queue.add(stringRequest);

    }

    public void savePostInDB(Map<String, String> data, ServerCallbackJSONArray serverCallbackJSONArray){
        RequestQueue queue = Volley.newRequestQueue(context);
        String url = URLConstants.BASE_URL + ":" + URLConstants.POST_PORT +
                "/" + URLConstants.POST_ROUTE + "/"
                + URLConstants.ADD_POST_END_POINT;
        JSONArray array = new JSONArray();
        array.put(new JSONObject(data));
        JSONObject obj = new JSONObject();
        try {
            obj.put("payload", array);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        // Request a string response from the provided URL.
        JsonObjectRequest stringRequest = new JsonObjectRequest(Request.Method.POST, url, obj,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        // Display the first 500 characters of the response string.
                        System.out.println(response);
                        try {
                            if (response.get("response").equals(ApplicationConstants.RESPONSE_SUCCESS)){
                                serverCallbackJSONArray.onSuccess(null);
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        }
        ){
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();
                params.put("Content-Type", "application/json; charset=UTF-8");
                SharedPreferences sharedPref = context.getSharedPreferences(ApplicationConstants.SHAREDPREF_FILE,
                        context.MODE_PRIVATE);
                String token = sharedPref.getString(context.getString(R.string.auth_token), "");
                params.put("Authorization", token);
                return params;
            }
        };
        //Add the request to the RequestQueue.
        queue.add(stringRequest);

    }

    public void getPosts(ServerCallbackJSONArray serverCallbackJSONArray){
        postList = new ArrayList<>();
        RequestQueue queue = Volley.newRequestQueue(this.context);
        JSONObject postData = new JSONObject();

        String url = URLConstants.BASE_URL + ":" + URLConstants.POST_PORT +
                "/" + URLConstants.POST_ROUTE + "/"
                + URLConstants.GET_POST_END_POINT;

        // Request a string response from the provided URL.
        JsonObjectRequest stringRequest = new JsonObjectRequest(Request.Method.POST, url, postData,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        // Display the first 500 characters of the response string.
                        System.out.println(response);
                        try {
                            JSONArray array = response.getJSONArray("posts");
                            for (int i = 0; i < array.length(); i++) {
                                JSONObject obj = array.getJSONObject(i);
                                Post post = new Post();
                                post.setPost_id(obj.getString("post_id"));
                                post.setPost_desc(obj.getString("post_desc"));
                                post.setPost_heading(obj.getString("post_heading"));
                                post.setPosted_by(obj.getString("posted_by"));
                                post.setDue_date(obj.getString("due_date"));
                                post.setCreated_at(obj.getString("created_at"));
                                postList.add(post);
                            }
                            serverCallbackJSONArray.onSuccess(postList);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        }
        ){
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();
                params.put("Content-Type", "application/json; charset=UTF-8");
                SharedPreferences sharedPref = context.getSharedPreferences(ApplicationConstants.SHAREDPREF_FILE,
                        context.MODE_PRIVATE);
                String token = sharedPref.getString(context.getString(R.string.auth_token), "");
                params.put("Authorization", token);
                return params;
            }
        };
        //Add the request to the RequestQueue.
        queue.add(stringRequest);

    }

    public void updatePostStatus(String postId,
                                 String status,
                                 ServerCallbackJSONArray serverCallbackJSONArray){
        RequestQueue queue = Volley.newRequestQueue(context);
        String url = URLConstants.BASE_URL + ":" + URLConstants.POST_PORT +
                "/" + URLConstants.POST_ROUTE + "/"
                + URLConstants.UPDATE_POST_STATUS_END_POINT;
        Toast.makeText(context, url, Toast.LENGTH_SHORT).show();
        JSONObject obj = new JSONObject();
        try {
            obj.put("post_id", postId);
            obj.put("status", status);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        // Request a string response from the provided URL.
        JsonObjectRequest stringRequest = new JsonObjectRequest(Request.Method.POST, url, obj,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        // Display the first 500 characters of the response string.
                        System.out.println(response);
                        try {
                            System.out.println(response.get("response"));
                            Toast.makeText(context,
                                    response.getString("message"),
                                    Toast.LENGTH_SHORT).show();
                            if (response.get("response").equals("SUCCESS")){
                                serverCallbackJSONArray.onSuccess(null);
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        }
        ){
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();
                params.put("Content-Type", "application/json; charset=UTF-8");
                SharedPreferences sharedPref = context.getSharedPreferences(ApplicationConstants.SHAREDPREF_FILE,
                        context.MODE_PRIVATE);
                String token = sharedPref.getString(context.getString(R.string.auth_token), "");
                params.put("Authorization", token);
                return params;
            }
        };
        //Add the request to the RequestQueue.
        queue.add(stringRequest);
    }

    public void getPostsForUser(String userid, ServerCallbackJSONArray serverCallbackJSONArray){
        postList = new ArrayList<>();
        RequestQueue queue = Volley.newRequestQueue(this.context);
        JSONObject postData = new JSONObject();
        try {
            postData.put("posted_by", userid);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        String url = URLConstants.BASE_URL + ":" + URLConstants.POST_PORT +
                "/" + URLConstants.POST_ROUTE + "/"
                + URLConstants.GET_USER_POST_END_POINT;

        // Request a string response from the provided URL.
        JsonObjectRequest stringRequest = new JsonObjectRequest(Request.Method.POST, url, postData,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        // Display the first 500 characters of the response string.
                        System.out.println(response);
                        try {
                            JSONArray array = response.getJSONArray("posts");
                            for (int i = 0; i < array.length(); i++) {
                                JSONObject obj = array.getJSONObject(i);
                                Post post = new Post();
                                post.setPost_id(obj.getString("post_id"));
                                post.setPost_desc(obj.getString("post_desc"));
                                post.setPost_heading(obj.getString("post_heading"));
                                post.setPosted_by(obj.getString("posted_by"));
                                post.setDue_date(obj.getString("due_date"));
                                post.setCreated_at(obj.getString("created_at"));
                                post.setStatus(obj.getString("status"));
                                postList.add(post);
                            }
                            serverCallbackJSONArray.onSuccess(postList);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        }
        ){
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();
                params.put("Content-Type", "application/json; charset=UTF-8");
                SharedPreferences sharedPref = context.getSharedPreferences(ApplicationConstants.SHAREDPREF_FILE,
                        context.MODE_PRIVATE);
                String token = sharedPref.getString(context.getString(R.string.auth_token), "");
                params.put("Authorization", token);
                return params;
            }
        };
        //Add the request to the RequestQueue.
        queue.add(stringRequest);

    }


}
