package com.example.collegebuddy.common;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentStatePagerAdapter;

import com.example.collegebuddy.constants.ApplicationConstants;


public class PostTabsAdapter extends FragmentStatePagerAdapter {

    int mNumOfTabs;
    Fragment fragment;


    public PostTabsAdapter(FragmentManager supportFragmentManager, int tabCount) {
        super(supportFragmentManager);
        this.mNumOfTabs = tabCount;
    }

    @NonNull
    @Override
    public Fragment getItem(int position) {
        switch (position){
            case 0:
                fragment = new PostListFragment();
                break;
            case 1:
                fragment = new InActivePostFragment();
                break;
        }
        return fragment;
    }


    @Override
    public int getCount() {
        return this.mNumOfTabs;
    }
}
