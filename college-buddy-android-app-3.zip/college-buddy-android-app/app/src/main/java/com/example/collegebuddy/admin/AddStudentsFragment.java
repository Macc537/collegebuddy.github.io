package com.example.collegebuddy.admin;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.example.collegebuddy.LandingActivity;
import com.example.collegebuddy.MainActivity;
import com.example.collegebuddy.R;
import com.example.collegebuddy.constants.ApplicationConstants;
import com.example.collegebuddy.constants.URLConstants;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;


public class AddStudentsFragment extends Fragment implements View.OnClickListener {

    private Button addStudentButton;
    private Button saveStudentButton;

    private LinearLayout dynamicContent;

    List<Map<String, String>> studentDetails = new ArrayList<>();

    public AddStudentsFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view =  inflater.inflate(R.layout.fragment_add_students, container, false);

        dynamicContent = (LinearLayout) view.findViewById(R.id.dynamic_content_student);
        addStudentButton = view.findViewById(R.id.add_student);
        addStudentButton.setOnClickListener(this);
        saveStudentButton = view.findViewById(R.id.save_details);
        saveStudentButton.setOnClickListener(this);
        saveStudentButton.setEnabled(false);
        return view;

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.add_student:
                createLayoutForAdd();
                break;
            case R.id.save_details:
                postStudentDetails();
                break;
        }
    }

    public void postStudentDetails(){

        RequestQueue queue = Volley.newRequestQueue(getContext());
        String url = URLConstants.BASE_URL + ":" + URLConstants.USERS_ROLES_PORT +
                "/" + URLConstants.USER_ROLES_ROUTE + "/"
                + URLConstants.ADD_USER_END_POINT;
        JSONArray array = new JSONArray();

        for(Map<String, String> data : studentDetails) {
            JSONObject obj = new JSONObject(data);
            array.put(obj);
        }

        JSONObject obj = new JSONObject();
        try {
            obj.put("payload", array);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        // Request a string response from the provided URL.
        JsonObjectRequest stringRequest = new JsonObjectRequest(Request.Method.POST, url, obj,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        // Display the first 500 characters of the response string.
                        System.out.println(response);
                        try {
                            String message = response.getString("message");
                            Toast.makeText(getActivity(), message, Toast.LENGTH_SHORT).show();
                            dynamicContent.removeAllViewsInLayout();
                            studentDetails = new ArrayList<>();
                            saveStudentButton.setEnabled(false);
                        } catch (Exception e) {
                            Toast.makeText(getActivity(), e.getMessage(), Toast.LENGTH_SHORT).show();
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        error.printStackTrace();
                }
                }
        ){
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();
                params.put("Content-Type", "application/json; charset=UTF-8");
                SharedPreferences sharedPref = getActivity().getSharedPreferences(ApplicationConstants.SHAREDPREF_FILE,
                        getActivity().MODE_PRIVATE);
                String token = sharedPref.getString(getString(R.string.auth_token), "");
                params.put("Authorization", token);
                return params;
            }
        };
        //Add the request to the RequestQueue.
        queue.add(stringRequest);


    }

    public void createLayoutForAdd(){
        // assuming your Wizard content is in content_wizard.xml
        View wizardView = getLayoutInflater()
                .inflate(R.layout.add_student_row, dynamicContent, false);

        // add the inflated View to the layout
        dynamicContent.addView(wizardView);

        Button addDetails = wizardView.findViewById(R.id.add_user_to_list);
        addDetails.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                EditText emailEditText = wizardView.findViewById(R.id.editTextUserName);
                EditText nameEditText = wizardView.findViewById(R.id.editTextName);
                EditText contactEditText = wizardView.findViewById(R.id.editTextContact);
                EditText addressEditText = wizardView.findViewById(R.id.editTextAddress);
                Map<String, String> studentMap = new HashMap<>();
                studentMap.put("email", String.valueOf(emailEditText.getText()));
                studentMap.put("contact", String.valueOf(contactEditText.getText()));
                studentMap.put("name", String.valueOf(nameEditText.getText()));
                studentMap.put("address", String.valueOf(addressEditText.getText()));
                studentMap.put("password", "password");
                studentMap.put("role_id", "1");

                if (addDetails.getText().toString().equals("Add")){
                    studentDetails.add(studentMap);
                    //dynamicContent.removeView(wizardView);
                    emailEditText.setEnabled(false);
                    nameEditText.setEnabled(false);
                    contactEditText.setEnabled(false);
                    addressEditText.setEnabled(false);
                    addDetails.setText("Delete");
                }else if (addDetails.getText().toString().equals("Delete")) {
                    studentDetails.remove(studentMap);
                    dynamicContent.removeView(wizardView);
                }
                if (studentDetails.size() > 0){
                    saveStudentButton.setEnabled(true);
                }else {
                    saveStudentButton.setEnabled(false);
                }

                //dynamicContent.removeView(wizardView);
            }
        });
    }
}