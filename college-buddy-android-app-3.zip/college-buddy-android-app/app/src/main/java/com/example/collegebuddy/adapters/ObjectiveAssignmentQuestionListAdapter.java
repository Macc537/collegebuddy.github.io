package com.example.collegebuddy.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.collegebuddy.R;
import com.example.collegebuddy.entities.AssignmentQuestion;

import java.util.List;

public class ObjectiveAssignmentQuestionListAdapter extends RecyclerView.Adapter<ObjectiveAssignmentQuestionListAdapter.ViewHolder>{

    private List<AssignmentQuestion> assignmentQuestionsList;
    private Context context;

    public ObjectiveAssignmentQuestionListAdapter(List<AssignmentQuestion> listData) {
        this.assignmentQuestionsList = listData;
    }

    public ObjectiveAssignmentQuestionListAdapter(List<AssignmentQuestion> assignmentQuestionsList, Context context) {
        this.assignmentQuestionsList = assignmentQuestionsList;
        this.context = context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View listItem = layoutInflater.inflate(R.layout.objective_question_card,
                parent, false);
        ObjectiveAssignmentQuestionListAdapter.ViewHolder viewHolder = new ObjectiveAssignmentQuestionListAdapter.ViewHolder(listItem);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        final AssignmentQuestion assignmentQuestion = assignmentQuestionsList.get(position);
        holder.textViewQuestionId.setText(assignmentQuestion.getQuestionId() + ". ");
        holder.textViewQuestionDesc.setText(assignmentQuestion.getQuestion_description());
        holder.textViewQuestionMarks.setText(assignmentQuestion.getQuestion_marks());

        ObjectiveQuestionOptionShowAdapter objectiveQuestionOptionShowAdapter = new ObjectiveQuestionOptionShowAdapter(assignmentQuestion.getOptions());
        holder.recyclerViewAssignmentOptions.setHasFixedSize(true);
        holder.recyclerViewAssignmentOptions.setLayoutManager(new LinearLayoutManager(context));
        holder.recyclerViewAssignmentOptions.setAdapter(objectiveQuestionOptionShowAdapter);
    }

    @Override
    public int getItemCount() {
        return assignmentQuestionsList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public TextView textViewQuestionId;
        public TextView textViewQuestionDesc;
        public TextView textViewQuestionMarks;
        public RecyclerView recyclerViewAssignmentOptions;


        public ViewHolder(View itemView) {
            super(itemView);
            this.textViewQuestionId = (TextView) itemView.findViewById(R.id.textViewQuestionId);
            this.textViewQuestionDesc = (TextView) itemView.findViewById(R.id.textViewQuestionDescription);
            this.textViewQuestionMarks = (TextView) itemView.findViewById(R.id.textViewQuestionMarks);
            this.recyclerViewAssignmentOptions = (RecyclerView) itemView.findViewById(R.id.recyclerViewAssignmentOptions);

        }
    }

}
