package com.example.collegebuddy.adapters;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.collegebuddy.R;
import com.example.collegebuddy.entities.Assignment;
import com.example.collegebuddy.entities.Post;
import com.example.collegebuddy.teacher.UploadObjectiveAssignmentQuestionsActivity;
import com.example.collegebuddy.teacher.UploadSubjectiveAssignmentQuestionsActivity;

import java.util.List;

public class PostListViewAdapter extends RecyclerView.Adapter<PostListViewAdapter.ViewHolder> {

    private List<Post> postList;
    private Context context;

    public PostListViewAdapter(List<Post> listData) {
        this.postList = listData;
    }

    public PostListViewAdapter(List<Post> postList, Context context) {
        this.postList = postList;
        this.context = context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View listItem = layoutInflater.inflate(R.layout.post_card_read_view,
                parent, false);
        PostListViewAdapter.ViewHolder viewHolder = new PostListViewAdapter.ViewHolder(listItem);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        final Post post = postList.get(position);


        holder.textViewPostHeading.setText(post.getPost_heading());
        holder.textViewPostDescription.setText(post.getPost_desc());
        holder.textViewPostDueDate.setText(post.getDue_date());
        holder.textViewPostCreatedTime.setText(post.getCreated_at());
        holder.textViewPostPostedBy.setText(post.getPosted_by());


    }

    @Override
    public int getItemCount() {
        return postList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public TextView textViewPostHeading;
        public TextView textViewPostDescription;
        public TextView textViewPostDueDate;
        public TextView textViewPostCreatedTime;
        public TextView textViewPostPostedBy;


        public ViewHolder(View itemView) {
            super(itemView);
            this.textViewPostHeading = (TextView) itemView.findViewById(R.id.textViewPostHeading);
            this.textViewPostDueDate = (TextView) itemView.findViewById(R.id.textViewPostDueDate);
            this.textViewPostDescription = (TextView) itemView.findViewById(R.id.textViewPostDescription);
            this.textViewPostCreatedTime = (TextView) itemView.findViewById(R.id.textViewPostCreatedTime);
            this.textViewPostPostedBy = (TextView) itemView.findViewById(R.id.textViewPostPostedBy);
        }
    }

}
