package com.example.collegebuddy.data;

import android.content.Context;
import android.content.SharedPreferences;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.example.collegebuddy.R;
import com.example.collegebuddy.callback.ServerCallbackJSONArray;
import com.example.collegebuddy.constants.ApplicationConstants;
import com.example.collegebuddy.constants.URLConstants;
import com.example.collegebuddy.entities.Assignment;
import com.example.collegebuddy.entities.AssignmentQuestion;
import com.example.collegebuddy.entities.AssignmentSubmission;
import com.example.collegebuddy.entities.User;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class AssignmentSubmissionsData {
    public Context context;
    private List<AssignmentSubmission> assignmentSubmissionsList = new ArrayList<>();

    public AssignmentSubmissionsData(Context context){
        this.context = context;
    }

    public void getAssignmentsSubmissions(String assignmentId, ServerCallbackJSONArray serverCallbackJSONArray){
        assignmentSubmissionsList = new ArrayList<>();
        RequestQueue queue = Volley.newRequestQueue(this.context);
        String url = URLConstants.BASE_URL + ":" + URLConstants.ASSIGNMENT_PORT +
                "/" + URLConstants.ASSIGNMENT_ROUTE + "/"
                + URLConstants.GET_ASSIGNMENT_SUBMISSIONS_END_POINT;
        JSONObject postData = new JSONObject();
        try {
            postData.put("assignment_id", assignmentId);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        JsonObjectRequest stringRequest = new JsonObjectRequest(Request.Method.POST, url, postData,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        // Display the first 500 characters of the response string.
                        try {
                            JSONArray array = response.getJSONArray("submissions");
                            for (int i = 0; i < array.length(); i++) {
                                JSONObject submissionObj = array.getJSONObject(i);
                                AssignmentSubmission submission = new AssignmentSubmission();
                                submission.setMarks(submissionObj.getString("marks"));
                                submission.setSubmittedTime(submissionObj.getString("submitted_time"));
                                submission.setSubmittedFile(submissionObj.getString("submission_file_path"));
                                submission.setStudent(new User(submissionObj.getString("user_id"),
                                        submissionObj.getString("name"), submissionObj.getString("email")));
                                submission.setAssignment(new Assignment(submissionObj.getString("assignment_id")));
                               assignmentSubmissionsList.add(submission);
                            }
                            serverCallbackJSONArray.onSuccess(assignmentSubmissionsList);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        }
        ){
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();
                params.put("Content-Type", "application/json; charset=UTF-8");
                SharedPreferences sharedPref = context.getSharedPreferences(ApplicationConstants.SHAREDPREF_FILE,
                        context.MODE_PRIVATE);
                String token = sharedPref.getString(context.getString(R.string.auth_token), "");
                params.put("Authorization", token);
                return params;
            }
        };
        queue.add(stringRequest);

    }


    public void updateAssignmentsSubmissions(JSONObject assignmentObj,
                                             ServerCallbackJSONArray serverCallbackJSONArray){
        RequestQueue queue = Volley.newRequestQueue(this.context);
        String url = URLConstants.BASE_URL + ":" + URLConstants.ASSIGNMENT_PORT +
                "/" + URLConstants.ASSIGNMENT_ROUTE + "/"
                + URLConstants.UPDATE_ASSIGNMENT_SUBMISSION_END_POINT;


        JsonObjectRequest stringRequest = new JsonObjectRequest(Request.Method.POST, url, assignmentObj,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        // Display the first 500 characters of the response string.
                        try {
                            Toast.makeText(context, response.getString("message"),
                                    Toast.LENGTH_SHORT).show();
                            if (response.getString("response").equals("SUCCESS")){
                                serverCallbackJSONArray.onSuccess(null);
                            }

                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        }
        ){
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();
                params.put("Content-Type", "application/json; charset=UTF-8");
                SharedPreferences sharedPref = context.getSharedPreferences(ApplicationConstants.SHAREDPREF_FILE,
                        context.MODE_PRIVATE);
                String token = sharedPref.getString(context.getString(R.string.auth_token), "");
                params.put("Authorization", token);
                return params;
            }
        };
        queue.add(stringRequest);
    }


    public void getStudentSubmission(JSONObject assignmentObj,
                                     ServerCallbackJSONArray serverCallbackJSONArray){
        assignmentSubmissionsList = new ArrayList<>();
        RequestQueue queue = Volley.newRequestQueue(this.context);
        String url = URLConstants.BASE_URL + ":" + URLConstants.ASSIGNMENT_PORT +
                "/" + URLConstants.ASSIGNMENT_ROUTE + "/"
                + URLConstants.GET_STUDENT_SUBMISSIONS_END_POINT;

        JsonObjectRequest stringRequest = new JsonObjectRequest(Request.Method.POST, url, assignmentObj,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        // Display the first 500 characters of the response string.
                        try {
                            Toast.makeText(context, response.getString("message"),
                                    Toast.LENGTH_SHORT).show();
                            if (response.getString("response").equals("SUCCESS")){
                                JSONArray array = response.getJSONArray("submission");
                                JSONObject obj = (JSONObject) array.get(0);

                                AssignmentSubmission submission = new AssignmentSubmission();
                                submission.setSubmittedFile(obj.getString("submission_file_path"));
                                submission.setMarks(obj.getString("marks"));
                                submission.setSubmittedTime(obj.getString("submitted_time"));
                                submission.setAssignment(new Assignment(obj.getString("assignment_id")));
                                submission.setStudent(new User(obj.getString("student_id")));
                                assignmentSubmissionsList.add(submission);
                                serverCallbackJSONArray.onSuccess(assignmentSubmissionsList);
                            }

                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        }
        ){
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();
                params.put("Content-Type", "application/json; charset=UTF-8");
                SharedPreferences sharedPref = context.getSharedPreferences(ApplicationConstants.SHAREDPREF_FILE,
                        context.MODE_PRIVATE);
                String token = sharedPref.getString(context.getString(R.string.auth_token), "");
                params.put("Authorization", token);
                return params;
            }
        };
        queue.add(stringRequest);
    }

}
