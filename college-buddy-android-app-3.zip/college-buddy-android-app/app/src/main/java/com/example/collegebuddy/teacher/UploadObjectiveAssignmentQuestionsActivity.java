package com.example.collegebuddy.teacher;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.collegebuddy.R;
import com.example.collegebuddy.adapters.AssignmentQuestionsListAdapter;
import com.example.collegebuddy.adapters.ObjectiveAssignmentQuestionListAdapter;
import com.example.collegebuddy.adapters.ObjectiveQuestionOptionAdapter;
import com.example.collegebuddy.adapters.PostListAdapter;
import com.example.collegebuddy.callback.ServerCallbackJSONArray;
import com.example.collegebuddy.constants.ApplicationConstants;
import com.example.collegebuddy.data.AssignmentQuestionsData;
import com.example.collegebuddy.entities.AssignmentQuestion;
import com.example.collegebuddy.entities.ObjectiveOption;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class UploadObjectiveAssignmentQuestionsActivity extends AppCompatActivity implements View.OnClickListener {

    Button addQuestionBtn;
    RecyclerView recyclerViewAssignmentQuestions;
    TextView textViewAssignmentName;
    String assignment_id, assignmentName;
    List<AssignmentQuestion> assignmentQuestions = new ArrayList<>();
    AssignmentQuestionsData assignmentQuestionsData;
    ObjectiveAssignmentQuestionListAdapter objectiveAssignmentQuestionListAdapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_upload_objective_assignment);
        assignmentQuestionsData = new AssignmentQuestionsData(getApplicationContext());

        Intent intent = getIntent();
        assignment_id = intent.getStringExtra("assignment_id");
        assignmentName = intent.getStringExtra("assignmentName");

        textViewAssignmentName = findViewById(R.id.textviewassignmentName);
        textViewAssignmentName.setText(assignmentName);
        addQuestionBtn = findViewById(R.id.buttonAddAssignmentQuestion);
        addQuestionBtn.setOnClickListener(this);
        recyclerViewAssignmentQuestions = findViewById(R.id.recyclerViewAssignmentQuestions);
        objectiveAssignmentQuestionListAdapter = new ObjectiveAssignmentQuestionListAdapter(assignmentQuestions, getApplicationContext());
        recyclerViewAssignmentQuestions.setAdapter(objectiveAssignmentQuestionListAdapter);
        recyclerViewAssignmentQuestions.setLayoutManager(new LinearLayoutManager(getApplicationContext()));

    }


    @Override
    protected void onResume() {
        super.onResume();
        assignmentQuestionsData.getObjectiveAssignmentsQuestions(assignment_id, new ServerCallbackJSONArray() {
            @Override
            public void onSuccess(List result) {
                assignmentQuestions = result;
                objectiveAssignmentQuestionListAdapter = new ObjectiveAssignmentQuestionListAdapter(assignmentQuestions, getApplicationContext());
                recyclerViewAssignmentQuestions.setAdapter(objectiveAssignmentQuestionListAdapter);
            }
        });

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.buttonAddAssignmentQuestion:
                AlertDialog.Builder builder = new AlertDialog.Builder(this);
                builder.setTitle("Add Question");
                LayoutInflater layoutInflater = getLayoutInflater();
                final View inflator = layoutInflater.inflate(R.layout.objective_question_dialog, null);

                final EditText questionDescEditText = (EditText) inflator.findViewById(R.id.question_description);
                final EditText questionMarksEditText = (EditText) inflator.findViewById(R.id.question_marks);
                ImageButton imageViewAddOption = (ImageButton) inflator.findViewById(R.id.imageButtonAddOption);
                RecyclerView questionOptionsRecyclerView = (RecyclerView) inflator.findViewById(R.id.recyclerViewQuestionOptionsView);
                questionOptionsRecyclerView.setHasFixedSize(false);
                questionOptionsRecyclerView.setLayoutManager(new LinearLayoutManager(getApplicationContext()));

                List<ObjectiveOption> objectiveOptionList = new ArrayList<>();
                objectiveOptionList.add(new ObjectiveOption("1", ""));
                objectiveOptionList.add(new ObjectiveOption("2", ""));
                System.out.println(objectiveOptionList.size());

                ObjectiveQuestionOptionAdapter objectiveQuestionOptionAdapter = new ObjectiveQuestionOptionAdapter(objectiveOptionList, getApplicationContext());
                questionOptionsRecyclerView.setAdapter(objectiveQuestionOptionAdapter);

                imageViewAddOption.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Integer pos = objectiveOptionList.size() + 1;
                        String key = String.valueOf(pos);
                        ObjectiveOption option = new ObjectiveOption(key, "");
                        objectiveOptionList.add(option);
                        objectiveQuestionOptionAdapter.notifyItemInserted(pos);
                    }
                });

                final EditText questionAnswerEditText = (EditText) inflator.findViewById(R.id.question_answer);

                builder.setView(inflator)
                        .setPositiveButton(R.string.add_question, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                String ques = String.valueOf(questionDescEditText.getText());
                                String quesMarks = String.valueOf(questionMarksEditText.getText());
                                String quesAns = String.valueOf(questionAnswerEditText.getText());
                                JSONArray optionArray = new JSONArray();
                                for (int i = 0; i < objectiveOptionList.size(); i++) {
                                    ObjectiveOption option = objectiveOptionList.get(i);
                                    JSONObject obj = new JSONObject();
                                    try {
                                        obj.put("option_id", option.getOptionKey());
                                        obj.put("option_desc", option.getOptionValue());
                                    } catch (JSONException e) {
                                        e.printStackTrace();
                                    }
                                    optionArray.put(obj);
                                }
                                JSONObject obj = new JSONObject();
                                try {
                                    obj.put("options", optionArray);
                                    obj.put("question_description",ques);
                                    obj.put("question_marks", quesMarks);
                                    obj.put("assignment_id", assignment_id);
                                    obj.put("question_id", String.valueOf(assignmentQuestions.size() + 1));
                                    obj.put("ques_ans", quesAns);
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }


                                assignmentQuestionsData.saveObjectiveQuestion(obj,
                                        new ServerCallbackJSONArray() {
                                    @Override
                                    public void onSuccess(List result) {
                                        AssignmentQuestion assignmentQuestion = new AssignmentQuestion();
                                        assignmentQuestion.setAssignmentId(assignment_id);
                                        assignmentQuestion.setQuestionId(String.valueOf(assignmentQuestions.size() + 1));
                                        assignmentQuestion.setQuestion_marks(quesMarks);
                                        assignmentQuestion.setCorrectOption(quesAns);
                                        assignmentQuestion.setQuestion_description(ques);
                                        assignmentQuestion.setOptions(objectiveOptionList);
                                        assignmentQuestions.add(assignmentQuestion);
                                        objectiveAssignmentQuestionListAdapter.notifyItemInserted(assignmentQuestions.size()-1);
                                    }

                                });
                            }
                        })
                        .setNegativeButton(R.string.cancel, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {

                            }
                        });
                builder.show();
                break;
        }

    }
}