package com.example.collegebuddy.entities;

public class Course {

    private String courseId;
    private String courseName;

    public Course(String courseId, String courseName) {
        this.courseId = courseId;
        this.courseName = courseName;
    }


    public String getCourseId() {
        return courseId;
    }

    public void setCourseId(String courseId) {
        this.courseId = courseId;
    }

    public String getCourseName() {
        return courseName;
    }

    public void setName(String courseName) {
        this.courseName = courseName;
    }


    //to display object as a string in spinner
    @Override
    public String toString() {
        return courseName;
    }

    @Override
    public boolean equals(Object obj) {
        if(obj instanceof Course){
            Course c = (Course )obj;
            if(c.getCourseName().equals(courseName) && c.getCourseId()==courseId ) return true;
        }

        return false;
    }
}
