package com.example.collegebuddy.entities;

public class Post {

    String post_id;
    String post_heading;
    String post_desc;
    String posted_by;
    String created_at;
    String status;
    String due_date;

    public Post(){

    }

    public Post(String post_id, String post_heading, String post_desc, String posted_by, String created_at, String status, String due_date) {
        this.post_id = post_id;
        this.post_heading = post_heading;
        this.post_desc = post_desc;
        this.posted_by = posted_by;
        this.created_at = created_at;
        this.status = status;
        this.due_date = due_date;
    }

    public String getPost_id() {
        return post_id;
    }

    public void setPost_id(String post_id) {
        this.post_id = post_id;
    }

    public String getPost_heading() {
        return post_heading;
    }

    public void setPost_heading(String post_heading) {
        this.post_heading = post_heading;
    }

    public String getPost_desc() {
        return post_desc;
    }

    public void setPost_desc(String post_desc) {
        this.post_desc = post_desc;
    }

    public String getPosted_by() {
        return posted_by;
    }

    public void setPosted_by(String posted_by) {
        this.posted_by = posted_by;
    }

    public String getCreated_at() {
        return created_at;
    }

    public void setCreated_at(String created_at) {
        this.created_at = created_at;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getDue_date() {
        return due_date;
    }

    public void setDue_date(String due_date) {
        this.due_date = due_date;
    }
}
