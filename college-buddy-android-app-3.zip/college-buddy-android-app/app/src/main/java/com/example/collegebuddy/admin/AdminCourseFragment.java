package com.example.collegebuddy.admin;

import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.example.collegebuddy.R;
import com.example.collegebuddy.constants.ApplicationConstants;
import com.example.collegebuddy.constants.URLConstants;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class AdminCourseFragment extends Fragment implements View.OnClickListener {

    private Button addCourseButton;
    private Button saveCourseButton;

    private LinearLayout dynamicContent;

    List<Map<String, String>> courseDetails = new ArrayList<>();

    public AdminCourseFragment() {
        // Required empty public constructor
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view =  inflater.inflate(R.layout.fragment_admin_course, container, false);

        dynamicContent = (LinearLayout) view.findViewById(R.id.dynamic_content_course);
        addCourseButton = view.findViewById(R.id.add_course);
        addCourseButton.setOnClickListener(this);
        saveCourseButton = view.findViewById(R.id.save_course_details);
        saveCourseButton.setOnClickListener(this);
        saveCourseButton.setEnabled(false);

        return view;
    }

    @Override
    public void onClick(View v) {

        switch (v.getId()){
            case R.id.add_course:
                createLayoutForCourseAdd();
                break;
            case R.id.save_course_details:
                postCourseDetails();
                break;
        }

    }

    public void postCourseDetails(){

        RequestQueue queue = Volley.newRequestQueue(getContext());
        String url = URLConstants.BASE_URL + ":" + URLConstants.COURSE_SUBJECT_PORT +
                "/" + URLConstants.COURSE_SUBJECT_ROUTE + "/"
                + URLConstants.ADD_COURSE_END_POINT;

        JSONArray array = new JSONArray();

        for(Map<String, String> data : courseDetails) {
            JSONObject obj = new JSONObject(data);
            array.put(obj);
        }

        JSONObject obj = new JSONObject();
        try {
            obj.put("payload", array);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        // Request a string response from the provided URL.
        JsonObjectRequest stringRequest = new JsonObjectRequest(Request.Method.POST, url, obj,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        // Display the first 500 characters of the response string.
                        System.out.println(response);
                        try {
                            Toast.makeText(getActivity(), response.getString("message"), Toast.LENGTH_SHORT).show();
                            dynamicContent.removeAllViewsInLayout();
                            courseDetails = new ArrayList<>();
                            saveCourseButton.setEnabled(false);
                        } catch (Exception e) {
                            Toast.makeText(getActivity(), e.getMessage(), Toast.LENGTH_SHORT).show();
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
                Toast.makeText(getActivity(), error.getMessage(), Toast.LENGTH_SHORT).show();

            }
        }
        ){
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();
                params.put("Content-Type", "application/json; charset=UTF-8");
                SharedPreferences sharedPref = getActivity().getSharedPreferences(ApplicationConstants.SHAREDPREF_FILE,
                        getActivity().MODE_PRIVATE);
                String token = sharedPref.getString(getString(R.string.auth_token), "");
                params.put("Authorization", token);
                return params;
            }
        };
        //Add the request to the RequestQueue.
        queue.add(stringRequest);


    }

    public void createLayoutForCourseAdd(){
        // assuming your Wizard content is in content_wizard.xml
        View wizardView = getLayoutInflater()
                .inflate(R.layout.add_course_row, dynamicContent, false);

        // add the inflated View to the layout
        dynamicContent.addView(wizardView);

        Button addDetails = wizardView.findViewById(R.id.add_course_to_list);
        addDetails.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                EditText courseIdEditText = wizardView.findViewById(R.id.editTextCourseID);
                EditText courseNameEditText = wizardView.findViewById(R.id.editTextCourseName);
                EditText courseDescriptionEditText = wizardView.findViewById(R.id.editTextCourseDescription);

                Map<String, String> courseMap = new HashMap<>();

                courseMap.put("course_id", String.valueOf(courseIdEditText.getText()));
                courseMap.put("course_name", String.valueOf(courseNameEditText.getText()));
                courseMap.put("course_description", String.valueOf(courseDescriptionEditText.getText()));

                if (addDetails.getText().toString().equals("Add")){
                    courseDetails.add(courseMap);
                    //dynamicContent.removeView(wizardView);
                    courseIdEditText.setEnabled(false);
                    courseNameEditText.setEnabled(false);
                    courseDescriptionEditText.setEnabled(false);
                    addDetails.setText("Delete");
                }else if (addDetails.getText().toString().equals("Delete")) {
                    courseDetails.remove(courseMap);
                    dynamicContent.removeView(wizardView);
                }
                if (courseDetails.size() > 0){
                    saveCourseButton.setEnabled(true);
                }else {
                    saveCourseButton.setEnabled(false);
                }
            }
        });
    }
}