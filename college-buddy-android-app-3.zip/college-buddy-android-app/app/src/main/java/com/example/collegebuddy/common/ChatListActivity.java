package com.example.collegebuddy.common;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.SharedPreferences;
import android.os.Bundle;

import com.example.collegebuddy.R;
import com.example.collegebuddy.adapters.CourseMaterialListAdapter;
import com.example.collegebuddy.callback.ServerCallbackJSONArray;
import com.example.collegebuddy.common.adapters.ChatListAdapter;
import com.example.collegebuddy.common.data.ChatData;
import com.example.collegebuddy.common.entities.Chat;
import com.example.collegebuddy.constants.ApplicationConstants;
import com.example.collegebuddy.data.PostData;

import java.util.ArrayList;
import java.util.List;

public class ChatListActivity extends AppCompatActivity {

    private String user_id;
    private RecyclerView chatListRecyclerView;

    List<Chat> chatLists = new ArrayList<>();

    private ChatData chatData ;
    private ChatListAdapter chatListAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat_list);
        SharedPreferences sharedPref = getSharedPreferences(ApplicationConstants.SHAREDPREF_FILE,
                MODE_PRIVATE);
        user_id = sharedPref.getString(getString(R.string.user_id), "");
        chatData = new ChatData(getApplicationContext());
        chatListRecyclerView = findViewById(R.id.recyclerViewChatList);
        chatListRecyclerView.setHasFixedSize(true);
        chatListRecyclerView.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
    }

    @Override
    public void onResume() {
        chatData.getChatsForUser(user_id, new ServerCallbackJSONArray() {
            @Override
            public void onSuccess(List result) {
                chatLists = result;
                chatListAdapter = new ChatListAdapter(chatLists, getApplicationContext());
                chatListRecyclerView.setAdapter(chatListAdapter);
            }
        });
        super.onResume();
    }
}