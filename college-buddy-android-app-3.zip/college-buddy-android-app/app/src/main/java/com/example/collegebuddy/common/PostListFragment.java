package com.example.collegebuddy.common;

import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.collegebuddy.R;
import com.example.collegebuddy.adapters.PostListViewAdapter;
import com.example.collegebuddy.callback.ServerCallbackJSONArray;
import com.example.collegebuddy.constants.ApplicationConstants;
import com.example.collegebuddy.data.PostData;
import com.example.collegebuddy.entities.Post;
import com.example.collegebuddy.student.adapters.AssignmentListAdapter;

import java.util.ArrayList;
import java.util.List;


public class PostListFragment extends Fragment {

    private String user_id;
    private RecyclerView postListRecyclerView;

    List<Post> postList = new ArrayList<>();
    List<Post> inActivePostList = new ArrayList<>();

    private PostData postData ;


    public PostListFragment() {
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view =  inflater.inflate(R.layout.fragment_post_list, container, false);

        SharedPreferences sharedPref = getContext().getSharedPreferences(ApplicationConstants.SHAREDPREF_FILE,
                getContext().MODE_PRIVATE);
        user_id = sharedPref.getString(getString(R.string.user_id), "");
        postData = new PostData(getContext());
        postListRecyclerView = (RecyclerView) view.findViewById(R.id.recyclerViewPostList);

        postListRecyclerView.setHasFixedSize(true);
        postListRecyclerView.setLayoutManager(new LinearLayoutManager(getContext()));



        postData.getPostsForUser(user_id, new ServerCallbackJSONArray() {
            @Override
            public void onSuccess(List result) {
                for (int i = 0 ; i < result.size(); i++){
                    Post post = (Post) result.get(i);
                    if (post.getStatus().equals(ApplicationConstants.POST_ACTIVE_STATUS)){
                        postList.add(post);
                    }
                }
                System.out.println(postList.size() );
                PostListViewAdapter activePostListAdapter = new PostListViewAdapter(postList, getContext());
                postListRecyclerView.setAdapter(activePostListAdapter);
                System.out.println("ACTIVE");
            }
        });
        return view;
    }

    @Override
    public void onResume() {
        super.onResume();
    }
}