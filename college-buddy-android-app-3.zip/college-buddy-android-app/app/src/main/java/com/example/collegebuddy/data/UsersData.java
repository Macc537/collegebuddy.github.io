package com.example.collegebuddy.data;

import android.content.Context;
import android.content.SharedPreferences;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.collegebuddy.R;
import com.example.collegebuddy.callback.ServerCallbackJSONArray;
import com.example.collegebuddy.constants.ApplicationConstants;
import com.example.collegebuddy.constants.URLConstants;
import com.example.collegebuddy.entities.Teacher;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class UsersData {

    public Context context;
    public List<Teacher> teachers;


    public UsersData(Context context){
        this.context = context;

    }

    public void loadTeachers(ServerCallbackJSONArray serverCallbackJSONArray){
        teachers = new ArrayList<>();
        RequestQueue queue = Volley.newRequestQueue(this.context);

        String url = URLConstants.BASE_URL + ":" + URLConstants.USERS_ROLES_PORT +
                "/" + URLConstants.USER_ROLES_ROUTE + "/"
                + URLConstants.GET_TEACHERS_END_POINT;

        // Request a string response from the provided URL.
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        // Display the first 500 characters of the response string.
                        System.out.println(response);
                        try {
                            JSONObject obj = new JSONObject(response);
                            JSONArray array = new JSONArray(obj.getString("teachers"));
                            for (int i = 0; i < array.length(); i++) {
                                JSONObject teacher = array.getJSONObject(i);
                                teachers.add(new Teacher(teacher.getString("teacher_id"),
                                        teacher.getString("teacher_name")));
                            }
                            serverCallbackJSONArray.onSuccess(teachers);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        }
        ){
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();
                params.put("Content-Type", "application/json; charset=UTF-8");
                SharedPreferences sharedPref = context.getSharedPreferences(ApplicationConstants.SHAREDPREF_FILE,
                        context.MODE_PRIVATE);
                String token = sharedPref.getString(context.getString(R.string.auth_token), "");
                params.put("Authorization", token);
                return params;
            }
        };
        //Add the request to the RequestQueue.
        queue.add(stringRequest);

    }


}
