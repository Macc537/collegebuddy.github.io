package com.example.collegebuddy.entities;

import java.io.Serializable;

public class AssignmentSubmission implements Serializable {
    Assignment assignment;
    User student;
    String submittedTime;
    String marks;
    String submittedFile;

    public AssignmentSubmission(){

    }

    public Assignment getAssignment() {
        return assignment;
    }

    public String getSubmittedFile() {
        return submittedFile;
    }

    public void setSubmittedFile(String submittedFile) {
        this.submittedFile = submittedFile;
    }

    public void setAssignment(Assignment assignment) {
        this.assignment = assignment;
    }

    public User getStudent() {
        return student;
    }

    public void setStudent(User student) {
        this.student = student;
    }

    public String getSubmittedTime() {
        return submittedTime;
    }

    public void setSubmittedTime(String submittedTime) {
        this.submittedTime = submittedTime;
    }

    public String getMarks() {
        return marks;
    }

    public void setMarks(String marks) {
        this.marks = marks;
    }
}
