package com.example.collegebuddy.constants;

import java.util.Set;

public class ApplicationConstants {

    public static String NO = "NO";
    public static String YES = "YES";

    public static String RESPONSE_ERROR = "ERROR";
    public static String RESPONSE_SUCCESS = "SUCCESS";
    public static String SHAREDPREF_FILE = "college_buddy_sp";

    public static String SESSION_YEAR = "2020-2021";
    public static String[] ASSIGNMENT_TYPES = {"Subjective", "Objective"};
    public static String SUBJECTIVE_ASSIGNMENT = "Subjective";

    public static Integer[] SEMESTER = {1, 2, 3, 4, 5, 6};

    public static String POST_ACTIVE_STATUS = "Active";
    public static String POST_IN_ACTIVE_STATUS = "Inactive";
    public static String POST_CLOSE_STATUS = "Close";


    public static String ASSIGNMENT_STATUS_COMPLETE = "Complete";


}
