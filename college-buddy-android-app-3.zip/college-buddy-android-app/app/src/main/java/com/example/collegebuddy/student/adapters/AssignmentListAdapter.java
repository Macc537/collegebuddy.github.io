package com.example.collegebuddy.student.adapters;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.collegebuddy.R;
import com.example.collegebuddy.constants.ApplicationConstants;
import com.example.collegebuddy.entities.Assignment;
import com.example.collegebuddy.student.ObjectiveAssignmentActivity;
import com.example.collegebuddy.student.SubjectiveAssignment;
import com.example.collegebuddy.teacher.UploadObjectiveAssignmentQuestionsActivity;
import com.example.collegebuddy.teacher.UploadSubjectiveAssignmentQuestionsActivity;

import java.util.List;


public class AssignmentListAdapter extends RecyclerView.Adapter<AssignmentListAdapter.ViewHolder> {

    private List<Assignment> assignmentList;
    private Context context;
    private Boolean isAssignmentSubmitted;

    public AssignmentListAdapter(List<Assignment> listData) {
        this.assignmentList = listData;
    }

    public AssignmentListAdapter(List<Assignment> assignmentList, Context context) {
        this.assignmentList = assignmentList;
        this.context = context;
        this.isAssignmentSubmitted = false;
    }

    public AssignmentListAdapter(List<Assignment> assignmentList, Context context, Boolean isAssignmentSubmitted) {
        this.assignmentList = assignmentList;
        this.context = context;
        this.isAssignmentSubmitted = isAssignmentSubmitted;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View listItem = layoutInflater.inflate(R.layout.student_assignment_card,
                parent, false);
        ViewHolder viewHolder = new ViewHolder(listItem);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        final Assignment assignment = assignmentList.get(position);
        holder.textViewCourseName.setText(" ("+assignment.getCourse().getCourseName()+")");
        holder.textViewSubjectName.setText(assignment.getSubject().getSubjectName());
        holder.textViewAssignmentName.setText(assignment.getAssignmentName());
        holder.textViewAssignmentDescription.setText(assignment.getAssignmentDescription());
        holder.textViewAssignmentDue.setText(assignment.getAssignmentDue());
        holder.textViewAssignmentUploadTime.setText(assignment.getCreatedTime());
        holder.textViewAssignmentType.setText(assignment.getAssignmentType());
        holder.textViewAssignmentStartTime.setText(assignment.getStartTime());


        if (isAssignmentSubmitted){
            holder.editAssignmentButton.setImageResource(R.drawable.ic_submission);
        }

        holder.editAssignmentButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = null;
                    if (assignment.getAssignmentType().equals(ApplicationConstants.SUBJECTIVE_ASSIGNMENT)){
                        intent = new Intent(context, SubjectiveAssignment.class);
                    }else {
                        intent = new Intent(context, ObjectiveAssignmentActivity.class);
                    }
                    intent.putExtra("assignment_id", assignment.getAssignmentId());
                    intent.putExtra("assignmentName", assignment.getAssignmentName());
                    intent.putExtra("course_subject_id", assignment.getCourseSubjectId());
                    intent.putExtra("is_assignment_submitted", String.valueOf(isAssignmentSubmitted));
                    context.startActivity(intent);
                }
        });

    }

    @Override
    public int getItemCount() {
        return assignmentList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public TextView textViewCourseName;
        public TextView textViewSubjectName;
        public TextView textViewAssignmentName;
        public TextView textViewAssignmentDescription;
        public TextView textViewAssignmentDue;
        public TextView textViewAssignmentUploadTime;
        public TextView textViewAssignmentType;
        public TextView textViewAssignmentStartTime;
        public ImageButton editAssignmentButton;


        public ViewHolder(View itemView) {
            super(itemView);
            this.textViewCourseName = (TextView) itemView.findViewById(R.id.textViewAssignmentCourseName);
            this.textViewSubjectName = (TextView) itemView.findViewById(R.id.textViewAssignmentSubjectName);
            this.textViewAssignmentName = (TextView) itemView.findViewById(R.id.textViewAssignmentName);
            this.textViewAssignmentDescription = (TextView) itemView.findViewById(R.id.textViewAssignmentDescription);
            this.textViewAssignmentDue = (TextView) itemView.findViewById(R.id.textViewAssignmentDue);
            this.textViewAssignmentUploadTime = (TextView) itemView.findViewById(R.id.textViewAssignmentUploadTime);
            this.textViewAssignmentType = (TextView) itemView.findViewById(R.id.textViewAssignmentType);
            this.textViewAssignmentStartTime = (TextView) itemView.findViewById(R.id.textViewAssignmentStartTime);
            this.editAssignmentButton = (ImageButton) itemView.findViewById(R.id.buttonEditAssignmentQuestions);
        }
    }

}
