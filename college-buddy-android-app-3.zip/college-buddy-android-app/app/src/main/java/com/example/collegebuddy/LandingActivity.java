package com.example.collegebuddy;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.example.collegebuddy.constants.ApplicationConstants;
import com.example.collegebuddy.constants.URLConstants;
import com.example.collegebuddy.utils.SharedPrefUtils;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashSet;
import java.util.Set;

public class LandingActivity extends AppCompatActivity {

    String userId;
    String newPassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_landing);

        SharedPreferences sharedPref = getSharedPreferences(ApplicationConstants.SHAREDPREF_FILE, MODE_PRIVATE);
        userId = sharedPref.getString(getString(R.string.user_id), "");
        String isFirstLogin = sharedPref.getString(getString(R.string.is_first_time), "");
        Set<String> defaultRoles = new HashSet<>();
        defaultRoles.add("student");

        if (isFirstLogin.equals(ApplicationConstants.NO)){
            Set<String> roles = sharedPref.getStringSet(getString(R.string.user_roles), defaultRoles);

            int rolesSize = roles.size();
            if (rolesSize == 1){
                switchActivity((String) roles.toArray()[0]);
            }
        }else{
            EditText editTextNewPassword, editTextConfirmPassword;
            editTextNewPassword = findViewById(R.id.editTextNewPassword);
            editTextConfirmPassword = findViewById(R.id.editTextConfirmPassword);
            Button buttonUpdatePassword = findViewById(R.id.buttonUpdatePassword);
            buttonUpdatePassword.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    SharedPrefUtils sharedPrefUtils = new SharedPrefUtils(getApplicationContext());
                    sharedPrefUtils.clearAuthSavedData();
                    newPassword = String.valueOf(editTextNewPassword.getText());
                    String confirmNewPassword = String.valueOf(editTextConfirmPassword.getText());
                    if (!newPassword.equals(confirmNewPassword)){
                        Toast.makeText(getApplicationContext(), "Password Doesn't Match", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    updatePassword();


                }
            });

        }
    }

    public void switchActivity(String role){
        System.out.println(role);
        switch (role){
            case "admin":
                Intent adminActivity = new Intent(getApplicationContext(),AdminActivity.class);
                finish();
                startActivity(adminActivity);
                break;
            case "teacher":
                Intent teacherActivity = new Intent(getApplicationContext(), TeacherActivity.class);
                finish();
                startActivity(teacherActivity);
                break;
            case "student":
                Intent studentActivity = new Intent(getApplicationContext(), StudentActivity.class);
                finish();
                startActivity(studentActivity);
                break;
        }
    }

    public void updatePassword() {
        // Instantiate the RequestQueue.
        RequestQueue queue = Volley.newRequestQueue(this);
        String url = URLConstants.BASE_URL + ":" + URLConstants.AUTH_PORT +
                "/" + URLConstants.AUTH_ROUTE + "/"
                + URLConstants.UPDATE_PASSWORD_END_POINT;
        JSONObject postData = new JSONObject();
        try {
            postData.put("user_id", userId);
            postData.put("password", newPassword);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        // Request a string response from the provided URL.
        JsonObjectRequest stringRequest = new JsonObjectRequest(Request.Method.POST, url, postData,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        // Display the first 500 characters of the response string.
                        System.out.println(response);
                        try {
                            String status_code = response.getString("response");
                            String message = response.getString("message");
                            if (status_code.equals(ApplicationConstants.RESPONSE_ERROR)) {
                                Toast.makeText(getApplicationContext(), message, Toast.LENGTH_SHORT).show();
                            } else if (status_code.equals(ApplicationConstants.RESPONSE_SUCCESS)) {
                                Toast.makeText(getApplicationContext(), "Login Again to Continue", Toast.LENGTH_SHORT).show();
                                Intent i = new Intent(getApplicationContext(), MainActivity.class);
                                finish();
                                startActivity(i);
                            } else {
                                Toast.makeText(getApplicationContext(), "Unknown Response", Toast.LENGTH_SHORT).show();
                            }

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        }
        );
        //Add the request to the RequestQueue.
        queue.add(stringRequest);
    }
}