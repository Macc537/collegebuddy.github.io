package com.example.collegebuddy.teacher;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.example.collegebuddy.R;
import com.example.collegebuddy.callback.ServerCallbackJSONArray;
import com.example.collegebuddy.constants.ApplicationConstants;
import com.example.collegebuddy.constants.URLConstants;
import com.example.collegebuddy.data.CoursesData;
import com.example.collegebuddy.data.CoursesSubjectMappedData;
import com.example.collegebuddy.data.SubjectsData;
import com.example.collegebuddy.entities.Course;
import com.example.collegebuddy.entities.CourseSubjectTeacher;
import com.example.collegebuddy.entities.Subject;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class UploadAssignmentActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener, View.OnClickListener {
    Button saveAssignment;
    Spinner subjectSpinner;
    Spinner spinnerAssignmentType;

    EditText editTextAssignmentDescription;
    EditText editTextAssignmentDueDate;
    EditText editTextAssignmentTopic;
    EditText editTextAssignmentStartTime;

    private CoursesSubjectMappedData coursesSubjectMappedData;
    private List<CourseSubjectTeacher> mappedSubjects = new ArrayList<>();
    private List<String> assignmentTypeList = Arrays.asList(ApplicationConstants.ASSIGNMENT_TYPES);

    String teacher_id;
    CourseSubjectTeacher selectedSubject;

    String assignment_type;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_upload_assignment);
        SharedPreferences sharedPref = getSharedPreferences(ApplicationConstants.SHAREDPREF_FILE, MODE_PRIVATE);
        teacher_id = sharedPref.getString(getString(R.string.user_id), "");

        coursesSubjectMappedData = new CoursesSubjectMappedData(getApplicationContext());

        subjectSpinner = findViewById(R.id.spinner_course_subject_assignment);
        subjectSpinner.setOnItemSelectedListener(this);

        spinnerAssignmentType = (Spinner) findViewById(R.id.spinner_assignment_type);
        spinnerAssignmentType.setOnItemSelectedListener(this);
        ArrayAdapter<String> assignmentTypeDataAdapter = new ArrayAdapter<String>(getApplicationContext(),
                android.R.layout.simple_spinner_item,
                assignmentTypeList);
        assignmentTypeDataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerAssignmentType.setAdapter(assignmentTypeDataAdapter);


        editTextAssignmentDescription = findViewById(R.id.editTextAssignmentDescription);
        editTextAssignmentDueDate = findViewById(R.id.editTextAssignmentDue);
        editTextAssignmentTopic = findViewById(R.id.editTextAssignmentTopic);
        editTextAssignmentStartTime = findViewById(R.id.editTextAssignmentStartTime);

        saveAssignment = findViewById(R.id.buttonAddAssignment);
        saveAssignment.setOnClickListener(this);

        coursesSubjectMappedData.getTeacherSubjects(teacher_id, new ServerCallbackJSONArray() {
            @Override
            public void onSuccess(List result) {
                mappedSubjects = result;
                ArrayAdapter<CourseSubjectTeacher> dataAdapter = new ArrayAdapter<CourseSubjectTeacher>(getApplicationContext(),
                        android.R.layout.simple_spinner_item,
                        mappedSubjects);
                dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                subjectSpinner.setAdapter(dataAdapter);
            }
        });
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        switch (parent.getId()){
            case R.id.spinner_course_subject_assignment:
                System.out.println("subject selected");
                selectedSubject = mappedSubjects.get(position);
                break;
            case R.id.spinner_assignment_type:
                assignment_type = assignmentTypeList.get(position);
                break;
        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.buttonAddAssignment:
                saveAssignmentInDB();
        }

    }

    public void saveAssignmentInDB(){

        String assignmentName = String.valueOf(editTextAssignmentTopic.getText());
        String assignmentDesc = String.valueOf(editTextAssignmentDescription.getText());
        String assignmentDueDate = String.valueOf(editTextAssignmentDueDate.getText());
        String assignmentStartTime = String.valueOf(editTextAssignmentStartTime.getText());

        RequestQueue queue = Volley.newRequestQueue(getApplicationContext());
        String url = URLConstants.BASE_URL + ":" + URLConstants.ASSIGNMENT_PORT +
                "/" + URLConstants.ASSIGNMENT_ROUTE + "/"
                + URLConstants.ADD_ASSIGNMENT_END_POINT;

        JSONArray array = new JSONArray();

        Map<String, String> data = new HashMap<>();

        data.put("assignment_topic", assignmentName);
        data.put("assignment_description", assignmentDesc);
        data.put("due_date", assignmentDueDate);
        data.put("start_time", assignmentStartTime);
        data.put("teacher_id", teacher_id);
        data.put("assignment_type", assignment_type);
        data.put("course_subject_id", selectedSubject.getCourseSubjectId());

        SimpleDateFormat formatter = new SimpleDateFormat("dd.MM.yyyy.HH.mm.ss");
        Date date = new Date();
        String id = formatter.format(date);
        data.put("assignment_id", "A-"+id);
        array.put(new JSONObject(data));
        JSONObject obj = new JSONObject();
        try {
            obj.put("payload", array);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        JsonObjectRequest stringRequest = new JsonObjectRequest(Request.Method.POST, url, obj,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        // Display the first 500 characters of the response string.
                        System.out.println(response);
                        try {
                            System.out.println(response.get("response"));
                            System.out.println(response.get("message"));
                            String status_code = response.getString("response");
                            String message = response.getString("message");
                            finish();
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        }
        ){
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();
                params.put("Content-Type", "application/json; charset=UTF-8");
                SharedPreferences sharedPref = getSharedPreferences(ApplicationConstants.SHAREDPREF_FILE,
                        MODE_PRIVATE);
                String token = sharedPref.getString(getString(R.string.auth_token), "");
                params.put("Authorization", token);
                return params;
            }
        };
        //Add the request to the RequestQueue.
        queue.add(stringRequest);
    }
}