package com.example.collegebuddy.data;

import android.content.Context;
import android.content.SharedPreferences;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.example.collegebuddy.R;
import com.example.collegebuddy.callback.ServerCallbackJSONArray;
import com.example.collegebuddy.constants.ApplicationConstants;
import com.example.collegebuddy.constants.URLConstants;
import com.example.collegebuddy.entities.Assignment;
import com.example.collegebuddy.entities.Course;
import com.example.collegebuddy.entities.Subject;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class AssignmentData {
        public Context context;
        private List<Assignment> assignmentList;


        public AssignmentData(Context context) {
            this.context = context;
        }

    public void getAssignments(String teacher,
                               ServerCallbackJSONArray serverCallbackJSONArray){
        assignmentList = new ArrayList<>();
        RequestQueue queue = Volley.newRequestQueue(this.context);
        String url = URLConstants.BASE_URL + ":" + URLConstants.ASSIGNMENT_PORT +
                "/" + URLConstants.ASSIGNMENT_ROUTE + "/"
                + URLConstants.GET_TEACHER_ASSIGNMENTS_END_POINT;
        JSONObject postData = new JSONObject();
        try {
            postData.put("teacher_id", teacher);
            postData.put("session_year", ApplicationConstants.SESSION_YEAR);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        JsonObjectRequest stringRequest = new JsonObjectRequest(Request.Method.POST, url, postData,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        // Display the first 500 characters of the response string.
                        try {

                            JSONArray array = response.getJSONArray("assignments");
                            for (int i = 0; i < array.length(); i++) {
                                JSONObject assign = array.getJSONObject(i);
                                Assignment assignment = new Assignment();
                                assignment.setAssignmentName(assign.getString("assignment_topic"));
                                assignment.setAssignmentDescription(assign.getString("assignment_description"));
                                assignment.setAssignmentId(assign.getString("assignment_id"));
                                assignment.setStartTime(assign.getString("due_date"));
                                assignment.setAssignmentDue(assign.getString("due_date"));
                                assignment.setAssignmentType(assign.getString("assignment_type"));
                                assignment.setCourseSubjectId(assign.getString("course_subject_id"));
                                assignment.setCreatedTime(assign.getString("created_at"));
                                Subject subject = new Subject(assign.getString("subject_id"),
                                        assign.getString("subject_name"));
                                Course course =  new Course(assign.getString("course_id"),
                                        assign.getString("course_name"));
                                assignment.setSubject(subject);
                                assignment.setCourse(course);
                                assignmentList.add(assignment);
                            }
                            serverCallbackJSONArray.onSuccess(assignmentList);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        }
        ){
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();
                params.put("Content-Type", "application/json; charset=UTF-8");
                SharedPreferences sharedPref = context.getSharedPreferences(ApplicationConstants.SHAREDPREF_FILE,
                        context.MODE_PRIVATE);
                String token = sharedPref.getString(context.getString(R.string.auth_token), "");
                params.put("Authorization", token);
                return params;
            }
        };
        queue.add(stringRequest);
    }



    public void getAssignmentsStudents(String student,
                                       ServerCallbackJSONArray serverCallbackJSONArray){
        assignmentList = new ArrayList<>();
        RequestQueue queue = Volley.newRequestQueue(this.context);
        String url = URLConstants.BASE_URL + ":" + URLConstants.ASSIGNMENT_PORT +
                "/" + URLConstants.ASSIGNMENT_ROUTE + "/"
                + URLConstants.GET_STUDENT_ASSIGNMENTS_END_POINT;
        JSONObject postData = new JSONObject();
        try {
            postData.put("student_id", student);
            postData.put("session_year", ApplicationConstants.SESSION_YEAR);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        JsonObjectRequest stringRequest = new JsonObjectRequest(Request.Method.POST, url, postData,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        // Display the first 500 characters of the response string.
                        try {

                            JSONArray array = response.getJSONArray("assignments");
                            for (int i = 0; i < array.length(); i++) {
                                JSONObject assign = array.getJSONObject(i);
                                Assignment assignment = new Assignment();
                                assignment.setAssignmentName(assign.getString("assignment_topic"));
                                assignment.setAssignmentDescription(assign.getString("assignment_description"));
                                assignment.setAssignmentId(assign.getString("assignment_id"));
                                assignment.setAssignmentDue(assign.getString("due_date"));
                                assignment.setAssignmentType(assign.getString("assignment_type"));
                                assignment.setCourseSubjectId(assign.getString("course_subject_id"));
                                assignment.setStartTime(assign.getString("start_time"));
                                assignment.setCreatedTime(assign.getString("created_at"));
                                Subject subject = new Subject(assign.getString("subject_id"),
                                        assign.getString("subject_name"));
                                Course course =  new Course(assign.getString("course_id"),
                                        assign.getString("course_name"));
                                assignment.setSubject(subject);
                                assignment.setCourse(course);
                                assignmentList.add(assignment);
                            }
                            serverCallbackJSONArray.onSuccess(assignmentList);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        }
        ){
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();
                params.put("Content-Type", "application/json; charset=UTF-8");
                SharedPreferences sharedPref = context.getSharedPreferences(ApplicationConstants.SHAREDPREF_FILE,
                        context.MODE_PRIVATE);
                String token = sharedPref.getString(context.getString(R.string.auth_token), "");
                params.put("Authorization", token);
                return params;
            }
        };
        queue.add(stringRequest);
    }

    public void getSubmittedAssignmentsStudents(String student,
                                                ServerCallbackJSONArray serverCallbackJSONArray){
        assignmentList = new ArrayList<>();
        RequestQueue queue = Volley.newRequestQueue(this.context);
        String url = URLConstants.BASE_URL + ":" + URLConstants.ASSIGNMENT_PORT +
                "/" + URLConstants.ASSIGNMENT_ROUTE + "/"
                + URLConstants.GET_STUDENT_SUBMITTED_ASSIGNMENTS_END_POINT;
        JSONObject postData = new JSONObject();
        try {
            postData.put("student_id", student);
            postData.put("session_year", ApplicationConstants.SESSION_YEAR);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        JsonObjectRequest stringRequest = new JsonObjectRequest(Request.Method.POST, url, postData,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        // Display the first 500 characters of the response string.
                        try {

                            JSONArray array = response.getJSONArray("assignments");
                            for (int i = 0; i < array.length(); i++) {
                                JSONObject assign = array.getJSONObject(i);
                                Assignment assignment = new Assignment();
                                assignment.setAssignmentName(assign.getString("assignment_topic"));
                                assignment.setAssignmentDescription(assign.getString("assignment_description"));
                                assignment.setAssignmentId(assign.getString("assignment_id"));
                                assignment.setAssignmentDue(assign.getString("due_date"));
                                assignment.setAssignmentType(assign.getString("assignment_type"));
                                assignment.setCourseSubjectId(assign.getString("course_subject_id"));
                                assignment.setCreatedTime(assign.getString("created_at"));
                                assignment.setStartTime(assign.getString("start_time"));
                                Subject subject = new Subject(assign.getString("subject_id"),
                                        assign.getString("subject_name"));
                                Course course =  new Course(assign.getString("course_id"),
                                        assign.getString("course_name"));
                                assignment.setSubject(subject);
                                assignment.setCourse(course);
                                assignmentList.add(assignment);
                            }
                            serverCallbackJSONArray.onSuccess(assignmentList);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        }
        ){
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();
                params.put("Content-Type", "application/json; charset=UTF-8");
                SharedPreferences sharedPref = context.getSharedPreferences(ApplicationConstants.SHAREDPREF_FILE,
                        context.MODE_PRIVATE);
                String token = sharedPref.getString(context.getString(R.string.auth_token), "");
                params.put("Authorization", token);
                return params;
            }
        };
        queue.add(stringRequest);
    }


    public void saveAssignmentsStudents(JSONObject assignmentObj,
                                        ServerCallbackJSONArray serverCallbackJSONArray){
        assignmentList = new ArrayList<>();
        RequestQueue queue = Volley.newRequestQueue(this.context);
        String url = URLConstants.BASE_URL + ":" + URLConstants.ASSIGNMENT_PORT +
                "/" + URLConstants.ASSIGNMENT_ROUTE + "/"
                + URLConstants.SUBMIT_ASSIGNMENT_END_POINT;
        JSONObject postObj = new JSONObject();
        JSONArray array = new JSONArray();
        array.put(assignmentObj);
        try {
            postObj.put("payload" , assignmentObj);
        } catch (JSONException e) {
            e.printStackTrace();
        }


        JsonObjectRequest stringRequest = new JsonObjectRequest(Request.Method.POST, url, postObj,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        // Display the first 500 characters of the response string.
                        try {
                            Toast.makeText(context, response.getString("message"), Toast.LENGTH_SHORT).show();
                            if (response.getString("response").equals("SUCCESS")){
                                serverCallbackJSONArray.onSuccess(assignmentList);
                            }

                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        }
        ){
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();
                params.put("Content-Type", "application/json; charset=UTF-8");
                SharedPreferences sharedPref = context.getSharedPreferences(ApplicationConstants.SHAREDPREF_FILE,
                        context.MODE_PRIVATE);
                String token = sharedPref.getString(context.getString(R.string.auth_token), "");
                params.put("Authorization", token);
                return params;
            }
        };
        queue.add(stringRequest);
    }

    public void deleteAssignments(JSONObject assignmentObj,
                                  ServerCallbackJSONArray serverCallbackJSONArray){
        assignmentList = new ArrayList<>();
        RequestQueue queue = Volley.newRequestQueue(this.context);
        String url = URLConstants.BASE_URL + ":" + URLConstants.ASSIGNMENT_PORT +
                "/" + URLConstants.ASSIGNMENT_ROUTE + "/"
                + URLConstants.DELETE_ASSIGNMENT_END_POINT;


        JsonObjectRequest stringRequest = new JsonObjectRequest(Request.Method.POST, url, assignmentObj,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        // Display the first 500 characters of the response string.
                        try {
                            Toast.makeText(context, response.getString("message"),
                                    Toast.LENGTH_SHORT).show();
                            if (response.getString("response").equals("SUCCESS")){
                                serverCallbackJSONArray.onSuccess(null);
                            }

                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        }
        ){
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();
                params.put("Content-Type", "application/json; charset=UTF-8");
                SharedPreferences sharedPref = context.getSharedPreferences(ApplicationConstants.SHAREDPREF_FILE,
                        context.MODE_PRIVATE);
                String token = sharedPref.getString(context.getString(R.string.auth_token), "");
                params.put("Authorization", token);
                return params;
            }
        };
        queue.add(stringRequest);
    }

    public void updateAssignmentsData(JSONObject assignmentObj,
                                  ServerCallbackJSONArray serverCallbackJSONArray){
        RequestQueue queue = Volley.newRequestQueue(this.context);
        String url = URLConstants.BASE_URL + ":" + URLConstants.ASSIGNMENT_PORT +
                "/" + URLConstants.ASSIGNMENT_ROUTE + "/"
                + URLConstants.UPDATE_ASSIGNMENT_END_POINT;


        JsonObjectRequest stringRequest = new JsonObjectRequest(Request.Method.POST, url, assignmentObj,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        // Display the first 500 characters of the response string.
                        try {
                            Toast.makeText(context, response.getString("message"),
                                    Toast.LENGTH_SHORT).show();
                            if (response.getString("response").equals("SUCCESS")){
                                serverCallbackJSONArray.onSuccess(null);
                            }

                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        }
        ){
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();
                params.put("Content-Type", "application/json; charset=UTF-8");
                SharedPreferences sharedPref = context.getSharedPreferences(ApplicationConstants.SHAREDPREF_FILE,
                        context.MODE_PRIVATE);
                String token = sharedPref.getString(context.getString(R.string.auth_token), "");
                params.put("Authorization", token);
                return params;
            }
        };
        queue.add(stringRequest);
    }


}
