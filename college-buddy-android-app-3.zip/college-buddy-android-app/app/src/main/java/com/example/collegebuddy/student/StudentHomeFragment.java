package com.example.collegebuddy.student;

import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.collegebuddy.R;
import com.example.collegebuddy.adapters.PostListViewAdapter;
import com.example.collegebuddy.callback.ServerCallbackJSONArray;
import com.example.collegebuddy.constants.ApplicationConstants;
import com.example.collegebuddy.data.PostData;
import com.example.collegebuddy.entities.Post;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class StudentHomeFragment extends Fragment implements View.OnClickListener {

    Button uploadPost;
    RecyclerView recyclerView;
    String student_id;
    private PostData postData ;
    List<Post> postList = new ArrayList<>();
    PostListViewAdapter postListAdapter;

    public StudentHomeFragment() {
        // Required empty public constructor
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        View view =  inflater.inflate(R.layout.fragment_student_home, container, false);

        uploadPost = view.findViewById(R.id.buttonAddPost);
        uploadPost.setOnClickListener(this);
        recyclerView = view.findViewById(R.id.recyclerViewPostView);
        SharedPreferences sharedPref = getContext().getSharedPreferences(ApplicationConstants.SHAREDPREF_FILE, getContext().MODE_PRIVATE);
        student_id = sharedPref.getString(getString(R.string.user_id), "");

        postData = new PostData(getContext());

        postData.getPosts(new ServerCallbackJSONArray() {
            @Override
            public void onSuccess(List result) {
                postList = result;
                postListAdapter = new PostListViewAdapter(postList);
                recyclerView.setHasFixedSize(true);
                recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
                recyclerView.setAdapter(postListAdapter);
            }
        });
        return view;
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.buttonAddPost:
                AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
                builder.setTitle("Add Post");
                LayoutInflater layoutInflater = getLayoutInflater();
                final View inflator = layoutInflater.inflate(R.layout.add_post_card, null);

                final EditText editTextPostHeading = (EditText) inflator.findViewById(R.id.editTextPostHeading);
                final EditText editTextPostDescription = (EditText) inflator.findViewById(R.id.editTextPostDescription);
                final EditText editTextPostDueDate = (EditText) inflator.findViewById(R.id.editTextPostDueDate);


                builder.setView(inflator)
                        .setPositiveButton(R.string.add_post, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                String postHead = String.valueOf(editTextPostHeading.getText());
                                String postDesc = String.valueOf(editTextPostDescription.getText());
                                String postDue = String.valueOf(editTextPostDueDate.getText());

                                Map<String, String> data = new HashMap<>();
                                data.put("post_heading",postHead);
                                data.put("post_desc", postDesc);
                                data.put("due_date", postDue);
                                data.put("status", ApplicationConstants.POST_IN_ACTIVE_STATUS);
                                SimpleDateFormat formatter = new SimpleDateFormat("dd.MM.yyyy.HH.mm.ss");
                                Date date = new Date();
                                String createdDate = formatter.format(date);
                                data.put("posted_by", student_id);
                                data.put("post_id", createdDate + "-" + student_id);
                                postData.savePostInDB(data, new ServerCallbackJSONArray() {
                                    @Override
                                    public void onSuccess(List result) {
                                        Toast.makeText(getActivity(), "Post Added Successfully, It is with Admin for review", Toast.LENGTH_SHORT).show();
                                    }
                                });
                            }
                        })
                        .setNegativeButton(R.string.cancel, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {

                            }
                        });
                builder.show();
                break;
        }

    }
}