package com.example.collegebuddy.data;

import android.content.Context;
import android.content.SharedPreferences;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.example.collegebuddy.R;
import com.example.collegebuddy.callback.ServerCallbackJSONArray;
import com.example.collegebuddy.constants.ApplicationConstants;
import com.example.collegebuddy.constants.URLConstants;
import com.example.collegebuddy.entities.Course;
import com.example.collegebuddy.entities.CourseSubjectMaterial;
import com.example.collegebuddy.entities.Subject;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class SubjectTopicsData {
    public Context context;
    private List<CourseSubjectMaterial> courseSubjectMaterialList;

    public SubjectTopicsData(Context context){
        this.context = context;
    }

    public void getSubjectTopicsTeacher( String teacher_id,
                                   ServerCallbackJSONArray serverCallbackJSONArray){
        courseSubjectMaterialList = new ArrayList<>();
        RequestQueue queue = Volley.newRequestQueue(this.context);
        JSONObject postData = new JSONObject();
        try {
            postData.put("teacher_id", teacher_id);
            postData.put("session_year", ApplicationConstants.SESSION_YEAR);

        } catch (JSONException e) {
            e.printStackTrace();
        }
        String url = URLConstants.BASE_URL + ":" + URLConstants.COURSE_SUBJECT_PORT +
                "/" + URLConstants.COURSE_SUBJECT_ROUTE + "/"
                + URLConstants.GET_TEACHER_SUBJECTS_TOPICS_END_POINT;

        // Request a string response from the provided URL.
        JsonObjectRequest stringRequest = new JsonObjectRequest(Request.Method.POST, url, postData,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        // Display the first 500 characters of the response string.
                        System.out.println(response);
                        try {
                            JSONArray array = response.getJSONArray("course_material");
                            for (int i = 0; i < array.length(); i++) {
                                JSONObject obj = array.getJSONObject(i);
                                CourseSubjectMaterial courseSubjectMaterial = new CourseSubjectMaterial();
                                courseSubjectMaterial.setSubject(new Subject(obj.getString("subject_id"), obj.getString("subject_name")));
                                courseSubjectMaterial.setCourse(new Course(obj.getString("course_id"), obj.getString("course_name")));
                                courseSubjectMaterial.setTopicName(obj.getString("topic_name"));
                                courseSubjectMaterial.setCourseSubjectId(obj.getString("course_subject_id"));
                                courseSubjectMaterial.setTopicDescription(obj.getString("topic_description"));
                                courseSubjectMaterial.setTopicRemarks(obj.getString("topic_remarks"));
                                courseSubjectMaterial.setTopicNotesPath(obj.getString("topic_notes_path"));
                                courseSubjectMaterial.setCreatedTime(obj.getString("created_time"));
                                courseSubjectMaterialList.add(courseSubjectMaterial);
                            }
                            serverCallbackJSONArray.onSuccess(courseSubjectMaterialList);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        }
        ){
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();
                params.put("Content-Type", "application/json; charset=UTF-8");
                SharedPreferences sharedPref = context.getSharedPreferences(ApplicationConstants.SHAREDPREF_FILE,
                        context.MODE_PRIVATE);
                String token = sharedPref.getString(context.getString(R.string.auth_token), "");
                params.put("Authorization", token);
                return params;
            }
        };
        //Add the request to the RequestQueue.
        queue.add(stringRequest);

    }


    public void getSubjectTopicsStudent(String student_id,
                                        ServerCallbackJSONArray serverCallbackJSONArray){
        courseSubjectMaterialList = new ArrayList<>();
        RequestQueue queue = Volley.newRequestQueue(this.context);
        JSONObject postData = new JSONObject();
        try {
            postData.put("student_id", student_id);
            postData.put("session_year", ApplicationConstants.SESSION_YEAR);

        } catch (JSONException e) {
            e.printStackTrace();
        }
        System.out.println(postData);
        String url = URLConstants.BASE_URL + ":" + URLConstants.COURSE_SUBJECT_PORT +
                "/" + URLConstants.COURSE_SUBJECT_ROUTE + "/"
                + URLConstants.GET_STUDENTS_SUBJECTS_TOPICS_END_POINT;

        // Request a string response from the provided URL.
        JsonObjectRequest stringRequest = new JsonObjectRequest(Request.Method.POST, url, postData,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        // Display the first 500 characters of the response string.
                        System.out.println(response);
                        try {
                            JSONArray array = response.getJSONArray("course_material");
                            for (int i = 0; i < array.length(); i++) {
                                JSONObject obj = array.getJSONObject(i);
                                CourseSubjectMaterial courseSubjectMaterial = new CourseSubjectMaterial();
                                courseSubjectMaterial.setSubject(new Subject(obj.getString("subject_id"), obj.getString("subject_name")));
                                courseSubjectMaterial.setCourse(new Course(obj.getString("course_id"), obj.getString("course_name")));
                                courseSubjectMaterial.setTopicName(obj.getString("topic_name"));
                                courseSubjectMaterial.setTopicDescription(obj.getString("topic_description"));
                                courseSubjectMaterial.setTopicRemarks(obj.getString("topic_remarks"));
                                courseSubjectMaterial.setTopicNotesPath(obj.getString("topic_notes_path"));
                                courseSubjectMaterial.setCreatedTime(obj.getString("created_time"));
                                courseSubjectMaterial.setCourseSubjectId(obj.getString("course_subject_id"));
                                courseSubjectMaterialList.add(courseSubjectMaterial);
                            }
                            serverCallbackJSONArray.onSuccess(courseSubjectMaterialList);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        }
        ){
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();
                params.put("Content-Type", "application/json; charset=UTF-8");
                SharedPreferences sharedPref = context.getSharedPreferences(ApplicationConstants.SHAREDPREF_FILE,
                        context.MODE_PRIVATE);
                String token = sharedPref.getString(context.getString(R.string.auth_token), "");
                params.put("Authorization", token);
                return params;
            }
        };
        //Add the request to the RequestQueue.
        queue.add(stringRequest);

    }
}
